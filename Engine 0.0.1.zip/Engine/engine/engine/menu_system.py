"""
Sistema di menu interattivo per Frontier Elite 2 ASCII Edition
"""
import curses
import time  # Aggiungo import mancante per time
from typing import List, Dict, Callable, Any, Optional
from .logger import get_logger
from .event_system import get_event_system, GameEventType
from .config import get_config  # Aggiungo import necessario per il config manager

logger = get_logger()
event_system = get_event_system()

class MenuItem:
    """Rappresenta una voce di menu."""
    def __init__(self, label: str, action: Optional[Callable] = None, submenu=None):
        """
        Inizializza un elemento del menu.
        
        Args:
            label: Il testo dell'elemento
            action: Funzione da chiamare quando l'elemento viene selezionato
            submenu: Sottomenu da aprire quando l'elemento viene selezionato
        """
        self.label = label
        self.action = action
        self.submenu = submenu
        self.enabled = True
        self.visible = True

class Menu:
    """Rappresenta un menu con varie opzioni."""
    def __init__(self, title: str, parent=None):
        """
        Inizializza un menu.
        
        Args:
            title: Il titolo del menu
            parent: Il menu genitore (None per menu principale)
        """
        self.title = title
        self.items: List[MenuItem] = []
        self.parent = parent
        self.selected_index = 0
        self.visible = True
        self.position = (0, 0)  # (x, y) posizione del menu
        self.width = 30
        self.height = 10
        self.border = True
        self.background = True
        self.on_close = None
    
    def add_item(self, label: str, action=None, submenu=None) -> MenuItem:
        """
        Aggiunge un elemento al menu.
        
        Args:
            label: Il testo dell'elemento
            action: Funzione da chiamare quando l'elemento viene selezionato
            submenu: Sottomenu da aprire quando l'elemento viene selezionato
        
        Returns:
            L'elemento aggiunto
        """
        item = MenuItem(label, action, submenu)
        self.items.append(item)
        return item
    
    def add_separator(self) -> MenuItem:
        """Aggiunge un separatore al menu."""
        item = MenuItem("---")
        item.enabled = False
        self.items.append(item)
        return item
    
    def set_position(self, x: int, y: int) -> None:
        """Imposta la posizione del menu."""
        self.position = (x, y)
    
    def set_size(self, width: int, height: int) -> None:
        """Imposta le dimensioni del menu."""
        self.width = width
        self.height = height
    
    def navigate(self, direction: int) -> None:
        """
        Naviga nel menu.
        
        Args:
            direction: +1 per giù, -1 per su
        """
        old_index = self.selected_index
        
        self.selected_index += direction
        
        # Salta elementi non visibili o non abilitati
        while 0 <= self.selected_index < len(self.items):
            item = self.items[self.selected_index]
            if not item.visible or not item.enabled or item.label == "---":
                self.selected_index += direction
            else:
                break
        
        # Correggi limiti
        self.selected_index = max(0, min(self.selected_index, len(self.items) - 1))
        
        # Se siamo ancora su un item disabilitato, torna alla posizione precedente
        if self.selected_index != old_index:
            item = self.items[self.selected_index]
            if not item.visible or not item.enabled or item.label == "---":
                self.selected_index = old_index
    
    def select(self) -> Any:
        """
        Seleziona l'elemento corrente e esegui l'azione o apri il sottomenu.
        
        Returns:
            Il risultato dell'azione o il sottomenu
        """
        if 0 <= self.selected_index < len(self.items):
            item = self.items[self.selected_index]
            
            if not item.enabled:
                return None
                
            if item.submenu:
                return item.submenu
            elif item.action:
                return item.action()
        
        return None

class MenuSystem:
    """Sistema di gestione dei menu del gioco."""
    
    def __init__(self, stdscr):
        """
        Inizializza il sistema di menu.
        
        Args:
            stdscr: Lo schermo curses principale
        """
        self.stdscr = stdscr
        self.menus: Dict[str, Menu] = {}
        self.current_menu: Optional[Menu] = None
        self.active = False
        self.breadcrumbs: List[Menu] = []
        self.width, self.height = stdscr.getmaxyx()
        self._current_view = "space"  # Vista corrente del gioco
        
        # Crea i menu predefiniti
        self._create_default_menus()
        
        # Gestione barra comandi separata dal sistema menu
        self.commands = {
            "space": [
                "W/A/S/D: Movimento | Q/E: Rollio | R/F: Vel+/- | T: Armi | ESC/TAB: Menu", 
                "M: Mappa | B: Attracca | I: Info | C: Cargo | G: Salva | H: Aiuto"
            ],
            "starmap": [
                "Frecce: Naviga | Invio: Seleziona | J: Salto | +/-: Zoom | ESC/TAB: Menu",
                "I: Info sistema | P: Prezzi | R: Rotte | M: Ritorna | G: Salva"
            ],
            "station": [
                "1-5: Servizi | ESC/TAB: Menu | B: Uscita",
                "Mercato: 1 | Equipaggiamento: 2 | Missioni: 3 | Notizie: 4 | Riparazioni: 5"
            ]
        }
        
        logger.info("Sistema di menu inizializzato")
    
    def _create_default_menus(self):
        """Crea i menu predefiniti del gioco."""
        # Menu principale
        main_menu = Menu("Menu Principale")
        main_menu.add_item("Gioco", submenu=self._create_game_menu())
        main_menu.add_item("Nave", submenu=self._create_ship_menu())
        main_menu.add_item("Navigazione", submenu=self._create_navigation_menu())
        main_menu.add_item("Commercio", submenu=self._create_trade_menu())
        main_menu.add_item("Informazioni", submenu=self._create_info_menu())
        main_menu.add_separator()
        main_menu.add_item("Esci dal menu", action=self.close_menu)
        
        self.menus["main"] = main_menu
        
    def _create_game_menu(self) -> Menu:
        """Crea il menu di gestione del gioco."""
        menu = Menu("Gioco", parent=self.menus.get("main"))
        menu.add_item("Salva partita", action=lambda: event_system.publish(GameEventType.GAME_SAVE, {'type': 'manual'}))
        menu.add_item("Carica partita")
        menu.add_separator()
        menu.add_item("Opzioni", submenu=self._create_options_menu())  # Collegamento al menu opzioni
        menu.add_item("Aiuto")
        menu.add_separator()
        menu.add_item("Esci dal gioco", action=self._exit_game)
        menu.add_separator()
        menu.add_item("Indietro", action=lambda: self.breadcrumbs.pop() if self.breadcrumbs else None)
        return menu
    
    def _create_options_menu(self) -> Menu:
        """Crea il menu opzioni."""
        menu = Menu("Opzioni", parent=self.menus.get("game"))
        
        # Sezione Grafica
        menu.add_item("Grafica", submenu=self._create_graphics_options_menu())
        
        # Sezione Gameplay
        menu.add_item("Gameplay", submenu=self._create_gameplay_options_menu())
        
        # Sezione Audio
        menu.add_item("Audio", submenu=self._create_audio_options_menu())
        
        # Sezione Controlli
        menu.add_item("Controlli", submenu=self._create_controls_options_menu())
        
        menu.add_separator()
        menu.add_item("Ripristina Default", action=self._reset_default_options)
        menu.add_item("Indietro", action=lambda: self.breadcrumbs.pop() if self.breadcrumbs else None)
        return menu
        
    def _create_graphics_options_menu(self) -> Menu:
        """Crea il menu delle opzioni grafiche."""
        config = get_config()
        menu = Menu("Opzioni Grafiche", parent=self.menus.get("options"))
        
        # Opzioni Z-Buffer
        z_buffer = config.get("graphics.use_z_buffer", True)
        menu.add_item(f"Z-Buffer: {'Attivo' if z_buffer else 'Disattivo'}", 
                    action=lambda: self._toggle_option_item(menu, 0, "Z-Buffer", "graphics.use_z_buffer"))
        
        # Opzioni Wireframe
        wireframe = config.get("graphics.render_wireframe", True)
        menu.add_item(f"Wireframe: {'Attivo' if wireframe else 'Disattivo'}",
                    action=lambda: self._toggle_option_item(menu, 1, "Wireframe", "graphics.render_wireframe"))
        
        # Opzioni Frustum Culling
        culling = config.get("graphics.frustum_culling", True)
        menu.add_item(f"Frustum Culling: {'Attivo' if culling else 'Disattivo'}",
                    action=lambda: self._toggle_option_item(menu, 2, "Frustum Culling", "graphics.frustum_culling"))
        
        # Opzioni FOV (Field of View)
        fov = config.get("graphics.fov", 60)
        menu.add_item(f"Campo Visivo: {fov}°", 
                    action=lambda: self._cycle_option_item(menu, 3, "Campo Visivo", 
                                                        "graphics.fov", [45, 60, 75, 90]))
                                                        
        # Opzione griglia mappa stellare
        show_grid = config.get("graphics.show_starmap_grid", True)
        menu.add_item(f"Griglia Mappa: {'Visibile' if show_grid else 'Nascosta'}",
                    action=lambda: self._toggle_option_item(menu, 4, "Griglia Mappa", "graphics.show_starmap_grid"))
        
        menu.add_separator()
        menu.add_item("Indietro", action=lambda: self.breadcrumbs.pop() if self.breadcrumbs else None)
        
        return menu
    
    def _create_gameplay_options_menu(self) -> Menu:
        """Crea il menu delle opzioni di gameplay."""
        config = get_config()
        menu = Menu("Opzioni Gameplay", parent=self.menus.get("options"))
        
        # FPS target
        target_fps = config.get("gameplay.target_fps", 30)
        menu.add_item(f"Target FPS: {target_fps}", 
                    action=lambda: self._cycle_option_item(menu, 0, "Target FPS", 
                                                        "gameplay.target_fps", [15, 30, 60]))
        
        # Mostra FPS
        show_fps = config.get("gameplay.show_fps", True)
        menu.add_item(f"Mostra FPS: {'Si' if show_fps else 'No'}", 
                    action=lambda: self._toggle_option_item(menu, 1, "Mostra FPS", "gameplay.show_fps"))
        
        # Difficoltà
        difficulty = config.get("gameplay.difficulty", "normal")
        difficulty_map = {"easy": "Facile", "normal": "Normale", "hard": "Difficile"}
        menu.add_item(f"Difficoltà: {difficulty_map.get(difficulty, 'Normale')}", 
                    action=lambda: self._cycle_option_item(menu, 2, "Difficoltà", 
                                                        "gameplay.difficulty", 
                                                        ["easy", "normal", "hard"]))
        
        menu.add_separator()
        menu.add_item("Indietro", action=lambda: self.breadcrumbs.pop() if self.breadcrumbs else None)
        
        return menu
    
    def _create_audio_options_menu(self) -> Menu:
        """Crea il menu delle opzioni audio."""
        config = get_config()
        menu = Menu("Opzioni Audio", parent=self.menus.get("options"))
        
        # Audio abilitato
        audio_enabled = config.get("audio.enabled", False)
        menu.add_item(f"Audio: {'Attivo' if audio_enabled else 'Disattivo'}", 
                    action=lambda: self._toggle_option_item(menu, 0, "Audio", "audio.enabled"))
        
        # Volume musica
        music_volume = int(config.get("audio.music_volume", 0.5) * 100)
        menu.add_item(f"Volume Musica: {music_volume}%", 
                    action=lambda: self._cycle_option_item(menu, 1, "Volume Musica", 
                                                        "audio.music_volume", 
                                                        [0.0, 0.25, 0.5, 0.75, 1.0]))
        
        # Volume effetti
        sfx_volume = int(config.get("audio.sfx_volume", 0.7) * 100)
        menu.add_item(f"Volume Effetti: {sfx_volume}%", 
                    action=lambda: self._cycle_option_item(menu, 2, "Volume Effetti", 
                                                        "audio.sfx_volume", 
                                                        [0.0, 0.25, 0.5, 0.75, 1.0]))
        
        menu.add_separator()
        menu.add_item("Indietro", action=lambda: self.breadcrumbs.pop() if self.breadcrumbs else None)
        
        return menu
    
    def _create_controls_options_menu(self) -> Menu:
        """Crea il menu delle opzioni di controllo."""
        config = get_config()
        menu = Menu("Opzioni Controlli", parent=self.menus.get("options"))
        
        # Sensibilità mouse
        sensitivity = config.get("controls.mouse_sensitivity", 1.0)
        menu.add_item(f"Sensibilità: {sensitivity}x", 
                    action=lambda: self._cycle_option_item(menu, 0, "Sensibilità", 
                                                        "controls.mouse_sensitivity", 
                                                        [0.5, 0.75, 1.0, 1.5, 2.0]))
        
        # Inverti asse Y
        invert_y = config.get("controls.invert_y", False)
        menu.add_item(f"Inverti Asse Y: {'Si' if invert_y else 'No'}", 
                    action=lambda: self._toggle_option_item(menu, 1, "Inverti Asse Y", "controls.invert_y"))
        
        # Ritardo ripetizione tasti
        key_delay = int(config.get("controls.key_repeat_delay", 0.15) * 1000)
        menu.add_item(f"Ritardo Tasti: {key_delay}ms", 
                    action=lambda: self._cycle_option_item(menu, 2, "Ritardo Tasti", 
                                                        "controls.key_repeat_delay", 
                                                        [0.05, 0.1, 0.15, 0.2, 0.25]))
        
        menu.add_separator()
        menu.add_item("Indietro", action=lambda: self.breadcrumbs.pop() if self.breadcrumbs else None)
        
        return menu
    
    def _toggle_option_item(self, menu, index, option_name, config_key):
        """Alterna un'opzione booleana."""
        config = get_config()
        current_value = config.get(config_key, False)
        new_value = not current_value
        config.set(config_key, new_value)
        config.save_config()
        
        # Aggiorna il testo dell'elemento di menu
        status = "Attivo" if new_value else "Disattivo"
        if "Griglia" in option_name:
            status = "Visibile" if new_value else "Nascosta"
        if option_name in ["Mostra FPS", "Inverti Asse Y"]:
            status = "Si" if new_value else "No"
            
        menu.items[index].label = f"{option_name}: {status}"
        
        # Pubblica una notifica
        event_system.publish(GameEventType.NOTIFICATION, {
            'message': f"{option_name} impostato a {status}",
            'color': 2  # Verde
        })
        
        # Pubblica un evento per informare altri sistemi della modifica
        event_system.publish(GameEventType.CONFIG_CHANGED, {
            'key': config_key,
            'value': new_value
        })
        
        return new_value
    
    def _cycle_option_item(self, menu, index, option_name, config_key, values):
        """Cicla attraverso una lista di valori per un'opzione."""
        config = get_config()
        current_value = config.get(config_key)
        
        # Trova l'indice attuale e passa al successivo
        try:
            current_idx = values.index(current_value)
        except ValueError:
            current_idx = 0
            
        next_idx = (current_idx + 1) % len(values)
        new_value = values[next_idx]
        
        # Aggiorna la configurazione
        config.set(config_key, new_value)
        config.save_config()
        
        # Formatta il valore per la visualizzazione
        display_value = new_value
        if config_key == "audio.music_volume" or config_key == "audio.sfx_volume":
            display_value = f"{int(new_value * 100)}%"
        elif config_key == "controls.key_repeat_delay":
            display_value = f"{int(new_value * 1000)}ms"
        elif config_key == "gameplay.difficulty":
            difficulty_map = {"easy": "Facile", "normal": "Normale", "hard": "Difficile"}
            display_value = difficulty_map.get(new_value, "Normale")
        elif config_key == "graphics.fov":
            display_value = f"{new_value}°"
        elif config_key == "controls.mouse_sensitivity":
            display_value = f"{new_value}x"
        
        # Aggiorna il testo dell'elemento di menu
        menu.items[index].label = f"{option_name}: {display_value}"
        
        # Pubblica una notifica
        event_system.publish(GameEventType.NOTIFICATION, {
            'message': f"{option_name} impostato a {display_value}",
            'color': 2  # Verde
        })
        
        # Pubblica un evento per informare altri sistemi della modifica
        event_system.publish(GameEventType.CONFIG_CHANGED, {
            'key': config_key,
            'value': new_value
        })
        
        return new_value
    
    def _reset_default_options(self):
        """Ripristina tutte le opzioni ai valori predefiniti."""
        config = get_config()
        # Reimporta i valori di default
        config.config = config.DEFAULT_CONFIG.copy()
        config.save_config()
        
        # Notifica l'utente
        event_system.publish(GameEventType.NOTIFICATION, {
            'message': "Opzioni reimpostate ai valori predefiniti",
            'color': 2  # Verde
        })
        
        # Pubblica un evento di reset completo
        event_system.publish(GameEventType.CONFIG_CHANGED, {
            'key': 'all',
            'value': 'default'
        })
        
        # Chiudi il menu e riapri per aggiornare i valori visualizzati
        self.close_menu()
        self.open_menu("main")
        
        return True
    
    def _exit_game(self) -> None:
        """Richiedi la conferma per uscire dal gioco."""
        # Chiudi prima il menu
        self.close_menu()
        
        # Pubblica un evento per richiedere la conferma di uscita
        event_system.publish(GameEventType.DIALOG_OPEN, {
            'title': "Conferma uscita",
            'message': "Sei sicuro di voler uscire dal gioco?",
            'options': ["Sì", "No"],
            'callback': self._confirm_exit
        })
    
    def _confirm_exit(self, choice: int) -> None:
        """Gestisce la risposta alla richiesta di conferma uscita."""
        if choice == 0:  # Sì
            event_system.publish(GameEventType.NOTIFICATION, {
                'message': "Uscita in corso...",
                'color': 7
            })
            
            # Pubblica evento per terminare il gioco
            event_system.publish(GameEventType.GAME_EXIT, {
                'reason': "user_request",
                'time': time.time()
            })

    def render_menu(self, menu: Menu) -> None:
        """Renderizza un menu sullo schermo."""
        if not menu or not menu.visible:
            return
            
        # Ricalcola posizione per il centraggio automatico migliorato
        if menu != self.menus.get("commands") and menu.position == (0, 0):
            width, height = menu.width, menu.height
            
            # Assicurati che le dimensioni siano valide
            visible_items = [item for item in menu.items if item.visible]
            needed_height = len(visible_items) + 2  # +2 per titolo e bordo
            height = max(height, needed_height)
            menu.height = height
            
            # Posiziona il menu al centro dello schermo
            x = (self.width - width) // 2
            y = (self.height - height) // 2
            menu.position = (x, y)
        
        x, y = menu.position
        width, height = menu.width, menu.height
        
        # Assicurati che le dimensioni siano valide
        visible_items = [item for item in menu.items if item.visible]
        needed_height = len(visible_items) + 2  # +2 per titolo e bordo
        height = max(height, needed_height)
        
        # Disegna lo sfondo colorato (blu chiaro semitrasparente)
        for iy in range(y+1, y + height-1):
            for ix in range(x+1, x + width-1):
                try:
                    self.stdscr.addch(iy, ix, ' ', curses.color_pair(4) | curses.A_REVERSE)
                except curses.error:
                    pass
        
        # Disegna il bordo più evidente
        if menu.border:
            try:
                # Bordo superiore e inferiore
                for ix in range(x, x + width):
                    self.stdscr.addch(y, ix, curses.ACS_HLINE, curses.color_pair(7) | curses.A_BOLD)
                    self.stdscr.addch(y + height - 1, ix, curses.ACS_HLINE, curses.color_pair(7) | curses.A_BOLD)
                    
                # Bordi laterali
                for iy in range(y, y + height):
                    self.stdscr.addch(iy, x, curses.ACS_VLINE, curses.color_pair(7) | curses.A_BOLD)
                    self.stdscr.addch(iy, x + width - 1, curses.ACS_VLINE, curses.color_pair(7) | curses.A_BOLD)
                    
                # Angoli
                self.stdscr.addch(y, x, curses.ACS_ULCORNER, curses.color_pair(7) | curses.A_BOLD)
                self.stdscr.addch(y, x + width - 1, curses.ACS_URCORNER, curses.color_pair(7) | curses.A_BOLD)
                self.stdscr.addch(y + height - 1, x, curses.ACS_LLCORNER, curses.color_pair(7) | curses.A_BOLD)
                self.stdscr.addch(y + height - 1, x + width - 1, curses.ACS_LRCORNER, curses.color_pair(7) | curses.A_BOLD)
            except curses.error:
                pass  # Ignora errori ai bordi

        # Disegna il titolo
        if menu.title:
            title_x = x + (width - len(menu.title)) // 2
            try:
                self.stdscr.addstr(y, title_x, f" {menu.title} ", curses.color_pair(3) | curses.A_BOLD)
            except curses.error:
                pass
        
        # Disegna gli elementi del menu
        item_y = y + 1
        for i, item in enumerate(menu.items):
            if not item.visible:
                continue
                
            # Sostituisci "Indietro" con "⬅ Indietro"
            if item.label == "Indietro":
                item.label = "⬅ Indietro"
                
            # Calcola l'attributo dell'elemento
            attr = curses.color_pair(7)  # Default
            
            if i == menu.selected_index and menu == self.current_menu:
                # Elemento selezionato - sfondo colorato
                attr = curses.color_pair(3) | curses.A_BOLD | curses.A_REVERSE
            elif not item.enabled:
                # Elemento disabilitato
                attr = curses.color_pair(8)  # Grigio scuro
                
            # Disegna l'elemento
            try:
                self.stdscr.addstr(item_y, x + 2, item.label, attr)
            except curses.error:
                pass
                
            # Aggiorna la posizione Y
            item_y += 1

    def update_command_menu(self, view: str) -> None:
        """
        Aggiorna il menu dei comandi in base alla vista corrente.
        
        Args:
            view: La vista corrente del gioco
        """
        command_menu = self.menus.get("commands")
        if not command_menu:
            return
            
        # Assicuriamoci che l'altezza e la posizione siano sempre corrette
        command_menu.height = 2
        command_menu.position = (0, self.height - 2)
        command_menu.width = self.width
        
        # Pulisci il menu
        command_menu.items = []
        
        # Aggiungi i comandi divisi in due righe CENTRATI
        if view == "space":
            command_menu.add_item("Movimento: W/A/S/D | Rollio: Q/E | Vel+/-: R/F | Armi: T | Menu: TAB/ESC")
            command_menu.add_item("Mappa: M | Attracca: B | Informazioni: I | Inventario: C | Salva: G")
        elif view == "starmap":
            command_menu.add_item("Naviga: FRECCE | Seleziona: INVIO | Salto: J | Zoom: +/- | Menu: TAB/ESC")
            command_menu.add_item("Info: I | Prezzi: P | Rotta: R | Ritorna: M | Salva: G")
        elif view == "station":
            command_menu.add_item("Mercato: 1 | Equipaggiamento: 2 | Missioni: 3 | Notizie: 4 | Riparazioni: 5")
            command_menu.add_item("Rifornimento: 6 | Mercenari: 7 | Menu: TAB/ESC | Esci: B | Salva: G")
    
    def open_menu(self, menu_name: str) -> None:
        """
        Apre un menu specifico.
        
        Args:
            menu_name: Il nome del menu da aprire
        """
        # Crea menu rapidi on-demand
        if menu_name == "weapons" and "weapons" not in self.menus:
            self.menus["weapons"] = self._create_weapons_menu()
        elif menu_name == "info" and "info" not in self.menus:
            self.menus["info"] = self._create_info_quick_menu()
        elif menu_name == "cargo" and "cargo" not in self.menus:
            self.menus["cargo"] = self._create_cargo_menu()
            
        # ...resto del codice esistente...
        if menu_name in self.menus:
            menu = self.menus[menu_name]
            
            # Posiziona il menu al centro se non ha una posizione specifica
            if menu.position == (0, 0):
                x = (self.width - menu.width) // 2
                y = (self.height - menu.height) // 2
                menu.position = (x, y)
            
            # Imposta il menu corrente
            self.current_menu = menu
            
            # Aggiungi il menu al percorso di navigazione
            if menu.parent and menu.parent != menu:
                self.breadcrumbs.append(menu.parent)
            
            self.active = True
            
            logger.debug(f"Menu aperto: {menu_name}")
    
    def close_menu(self) -> None:
        """Chiude il menu corrente."""
        if self.current_menu and self.current_menu.on_close:
            self.current_menu.on_close()
            
        self.current_menu = None
        self.breadcrumbs = []
        self.active = False
        
        logger.debug("Menu chiuso")
    
    def handle_input(self, key: int) -> bool:
        """
        Gestisce l'input per il menu corrente.
        
        Args:
            key: Il tasto premuto
            
        Returns:
            True se l'input è stato gestito, False altrimenti
        """
        if key == -1:  # Nessun input
            return False
            
        # Tasti per aprire il menu
        menu_keys = [27, 9]  # ESC e TAB
        
        if not self.active or not self.current_menu:
            # Apri il menu con ESC o TAB
            if key in menu_keys:
                logger.debug(f"Menu attivato con tasto {key}")
                self.open_menu("main")
                return True
                
            # Menu rapido delle info con I
            if key == ord('i'):
                logger.debug("Menu informazioni rapido")
                self.open_menu("info")
                return True
                
            # Menu rapido delle armi con T
            if key == ord('t'):
                logger.debug("Menu armi rapido")
                self.open_menu("weapons")
                return True
                
            # Menu rapido del cargo con C
            if key == ord('c'):
                logger.debug("Menu cargo rapido")
                self.open_menu("cargo")
                return True
                
            return False
        
        # Se il menu è attivo, gestisci la navigazione
        if key == curses.KEY_UP:
            self.current_menu.navigate(-1)
            return True
        elif key == curses.KEY_DOWN:
            self.current_menu.navigate(1)
            return True
        elif key == curses.KEY_ENTER or key == 10 or key == 13:  # Enter
            result = self.current_menu.select()
            if isinstance(result, Menu):
                self.current_menu = result
            return True
        elif key in menu_keys:  # ESC o TAB
            # Torna al menu precedente o chiudi
            if self.breadcrumbs:
                self.current_menu = self.breadcrumbs.pop()
            else:
                self.close_menu()
            return True
            
        return False
    
    def render(self) -> None:
        """Renderizza i menu attivi."""
        # Prima la barra comandi per essere sicuri che venga visualizzata
        self.render_command_bar()
        
        # Poi renderizza il menu attivo
        if self.active and self.current_menu:
            # Non permettere al menu di sovrapporsi alla barra comandi
            if self.current_menu != self.menus.get("commands"):
                self.render_menu(self.current_menu)
    
    def render_command_bar(self) -> None:
        """Renderizza la barra dei comandi in basso."""
        try:
            # Aggiorna le dimensioni del terminale prima di renderizzare
            # Fondamentale per gestire il ridimensionamento della finestra
            current_height, current_width = self.stdscr.getmaxyx()
            if current_height != self.height or current_width != self.width:
                self.width, self.height = current_width, current_height
                logger.debug(f"Dimensioni terminale aggiornate: {self.width}x{self.height}")
            
            # Calcola posizione per la barra comandi (sempre in fondo)
            command_y = self.height - 2  # 2 righe dal fondo
            
            # SEMPLIFICA: usa un approccio diretto per renderizzare i comandi
            # Invece di usare caratteri speciali e sfondi colorati che potrebbero causare problemi
            
            # Ottieni i comandi per la vista corrente o usa un default
            commands = self.commands.get(self._current_view, ["ESC/TAB: Menu | G: Salva"])
            if isinstance(commands, str):
                commands = [commands]
            
            # Disegna prima un separatore più evidente
            separator_y = self.height - 3
            if 0 <= separator_y < self.height:
                for x in range(self.width):
                    try:
                        self.stdscr.addch(separator_y, x, '═', curses.color_pair(8))
                    except curses.error:
                        pass
            
            # Disegna sfondo colorato per l'intera barra comandi (blu scuro)
            for y in range(self.height - 2, self.height):
                for x in range(0, self.width):
                    if 0 <= y < self.height and 0 <= x < self.width:
                        try:
                            self.stdscr.addch(y, x, ' ', curses.color_pair(4) | curses.A_REVERSE)
                        except curses.error:
                            pass
            
            # Disegna le linee di comando con caratteri migliori
            for i, cmd in enumerate(commands[:2]):
                y = self.height - 2 + i
                x = max(0, (self.width - len(cmd)) // 2)
                if y < self.height:
                    try:
                        self.stdscr.addstr(y, x, cmd, curses.color_pair(7) | curses.A_BOLD)
                    except curses.error:
                        pass
                        
        except Exception as e:
            logger.error(f"Errore nel renderizzare la barra comandi: {e}")
    
    def update_view(self, view: str) -> None:
        """
        Aggiorna la vista corrente per la visualizzazione dei comandi.
        
        Args:
            view: La nuova vista corrente
        """
        self._current_view = view
        logger.debug(f"Vista corrente aggiornata a {view}")

    def _create_ship_menu(self) -> Menu:
        """Crea il menu di gestione della nave."""
        menu = Menu("Nave", parent=self.menus.get("main"))
        menu.add_item("Stato", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                {'old_view': None, 'new_view': "ship_status"}))
        menu.add_item("Equipaggiamento", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                        {'old_view': None, 'new_view': "ship_equipment"}))
        menu.add_item("Cargo", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                              {'old_view': None, 'new_view': "ship_cargo"}))
        menu.add_item("Armi", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                             {'old_view': None, 'new_view': "ship_weapons"}))
        menu.add_item("Riparazioni", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                    {'old_view': None, 'new_view': "ship_repairs"}))
        menu.add_separator()
        menu.add_item("Indietro", action=lambda: self.breadcrumbs.pop() if self.breadcrumbs else None)
        return menu
    
    def _create_navigation_menu(self) -> Menu:
        """Crea il menu di navigazione."""
        menu = Menu("Navigazione", parent=self.menus.get("main"))
        menu.add_item("Mappa Stellare", action=lambda: self._switch_view("starmap"))
        menu.add_item("Sistemi vicini", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                      {'old_view': None, 'new_view': "nearby_systems"}))
        menu.add_item("Rotte salvate", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                    {'old_view': None, 'new_view': "saved_routes"}))
        menu.add_item("Iperguida", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                {'old_view': None, 'new_view': "hyperspace"}))
        menu.add_separator()
        menu.add_item("Indietro", action=lambda: self.breadcrumbs.pop() if self.breadcrumbs else None)
        return menu
    
    def _create_trade_menu(self) -> Menu:
        """Crea il menu di commercio."""
        menu = Menu("Commercio", parent=self.menus.get("main"))
        menu.add_item("Mercato", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                               {'old_view': None, 'new_view': "market"}))
        menu.add_item("Prezzi galattici", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                       {'old_view': None, 'new_view': "galactic_prices"}))
        menu.add_item("Rotte commerciali", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                        {'old_view': None, 'new_view': "trade_routes"}))
        menu.add_separator()
        menu.add_item("Indietro", action=lambda: self.breadcrumbs.pop() if self.breadcrumbs else None)
        return menu
    
    def _create_info_menu(self) -> Menu:
        """Crea il menu informazioni."""
        menu = Menu("Informazioni", parent=self.menus.get("main"))
        menu.add_item("Stato nave", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                 {'old_view': None, 'new_view': "ship_status"}))
        menu.add_item("Sistema corrente", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                      {'old_view': None, 'new_view': "system_info"}))
        menu.add_item("Missioni", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                {'old_view': None, 'new_view': "missions"}))
        menu.add_item("Crediti e statistiche", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                           {'old_view': None, 'new_view': "credits_stats"}))
        menu.add_separator()
        menu.add_item("Indietro", action=lambda: self.breadcrumbs.pop() if self.breadcrumbs else None)
        return menu
    
    def _switch_view(self, view: str) -> None:
        """Cambia la vista del gioco."""
        # Chiudi il menu
        self.close_menu()
        
        # Notifica il cambio di vista
        event_system.publish(GameEventType.VIEW_CHANGE, {
            'old_view': None,  # Il GameState aggiornerà questo valore
            'new_view': view
        })

    # Aggiungiamo nuovi menu rapidi
    def _create_weapons_menu(self) -> Menu:
        """Crea il menu rapido delle armi."""
        menu = Menu("Sistema d'Armi", parent=None)
        menu.add_item("Laser Primario", action=lambda: event_system.publish(GameEventType.PLAYER_FIRE, 
                                                                         {'weapon': 'laser_primary'}))
        menu.add_item("Missili", action=lambda: event_system.publish(GameEventType.PLAYER_FIRE, 
                                                                  {'weapon': 'missile'}))
        menu.add_item("Mine", action=lambda: event_system.publish(GameEventType.PLAYER_FIRE, 
                                                                {'weapon': 'mine'}))
        menu.add_separator()
        menu.add_item("Chiudi", action=self.close_menu)
        return menu
    
    def _create_info_quick_menu(self) -> Menu:
        """Crea il menu rapido delle informazioni."""
        menu = Menu("Informazioni", parent=None)
        menu.add_item("Stato Nave", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                      {'old_view': None, 'new_view': "ship_status"}))
        menu.add_item("Sistema Attuale", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                          {'old_view': None, 'new_view': "system_info"}))
        menu.add_item("Mappa Locale", action=lambda: self._switch_view("local_map"))
        menu.add_separator()
        menu.add_item("Chiudi", action=self.close_menu)
        return menu
    
    def _create_cargo_menu(self) -> Menu:
        """Crea il menu rapido del cargo."""
        menu = Menu("Cargo", parent=None)
        menu.add_item("Visualizza Inventario", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                                {'old_view': None, 'new_view': "inventory"}))
        menu.add_item("Trasferisci Merci", action=lambda: event_system.publish(GameEventType.VIEW_CHANGE, 
                                                                            {'old_view': None, 'new_view': "cargo_transfer"}))
        menu.add_separator()
        menu.add_item("Chiudi", action=self.close_menu)
        return menu

# Istanza globale del sistema di menu
_menu_system = None

def get_menu_system(stdscr=None):
    """Restituisce l'istanza globale del sistema di menu."""
    global _menu_system
    if _menu_system is None and stdscr is not None:
        _menu_system = MenuSystem(stdscr)
    return _menu_system
