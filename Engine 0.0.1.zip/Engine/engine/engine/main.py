#!/usr/bin/env python3
"""
Frontier Elite 2 - ASCII Edition
Un remake di Frontier Elite 2 per terminale ASCII
"""
import curses
import time
import sys
from engine.renderer import ASCIIRenderer
from engine.universe import Universe
from engine.ship import PlayerShip
from engine.ui import UserInterface
from engine.game_state import GameState
from .physics import get_physics_engine  # Aggiungi l'import del motore fisico
from .logger import Logger, get_Logger, Logger_info
from .config import config
def main(stdscr):
    # Inizializzazione del curses
    curses.start_color()
    curses.use_default_colors()
    curses.curs_set(0)  # Nascondi il cursore
    stdscr.timeout(50)  # Imposta il timeout per getch
    
    # Inizializza i colori
    for i in range(1, 8):
        curses.init_pair(i, i, curses.COLOR_BLACK)
    
    # Ottieni le dimensioni del terminale
    height, width = stdscr.getmaxyx()
    
    # Inizializza i componenti di gioco
    renderer = ASCIIRenderer(width, height)
    universe = Universe()
    player = PlayerShip()
    game_state = GameState(universe, player)
    ui = UserInterface(stdscr, width, height)
    logger = Logger_info ()
    # Inizializza il motore fisico
    physics_engine = get_physics_engine()
    
    # Registra oggetti fisici
    physics_engine.register_object("player", player)
    for i, system in enumerate(universe.systems):
        physics_engine.register_object(f"system_{i}", system)
        for j, planet in enumerate(system.planets):
            physics_engine.register_object(f"system_{i}_planet_{j}", planet)
    
    # Ciclo principale del gioco
    running = True
    last_time = time.time()
    
    try:
        logger.info("Inizio game loop")
        
        while running:
            current_time = time.time()
            delta_time = current_time - last_time
            last_time = current_time
            
            # Gestione dell'input
            key = stdscr.getch()
            if key == ord('x'):  # Cambiato da 'q' a 'x' per evitare conflitto
                running = False
            
            # Aggiorna la fisica
            physics_engine.update(delta_time)
            
            # Aggiorna l'universo
            universe.update(delta_time)
            
            # Aggiorna lo stato di gioco con il delta time accurato
            game_state.update(key, delta_time)
            
            # Cancella lo schermo
            stdscr.clear()
            
            # Renderizza il gioco
            if game_state.current_view == "space":
                renderer.render_space(stdscr, player, universe, game_state)
            elif game_state.current_view == "starmap":
                renderer.render_starmap(stdscr, player, universe, game_state)
            elif game_state.current_view == "station":
                renderer.render_station(stdscr, player, universe, game_state)
                
            # Renderizza l'UI
            ui.render(stdscr, game_state)
            
            # Aggiorna lo schermo
            stdscr.refresh()

    except KeyboardInterrupt:
        sys.exit(0)

if __name__ == "__main__":
    try:
        curses.wrapper(main)
    except KeyboardInterrupt:
        sys.exit(0)
