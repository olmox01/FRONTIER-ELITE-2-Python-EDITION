"""
Pacchetto engine per Frontier Elite 2 ASCII
"""
