"""
Sistema di logging per il gioco Frontier Elite 2 ASCII Edition
Fornisce funzionalità di debug e tracciamento degli errori
"""
import os
import time
import inspect
from enum import Enum

class LogLevel(Enum):
    """Livelli di logging supportati."""
    DEBUG = 0
    INFO = 1
    WARNING = 2
    ERROR = 3
    CRITICAL = 4

class Logger:
    """Sistema di logging con supporto per diversi livelli e output configurabile."""
    
    def __init__(self, log_dir="logs", log_level=LogLevel.INFO, console_output=True):
        """Inizializza il logger."""
        self.log_level = log_level
        self.console_output = console_output
        
        # Crea la directory dei log se non esiste
        self.log_dir = log_dir
        os.makedirs(self.log_dir, exist_ok=True)
        
        # Crea un nuovo file di log con timestamp
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        self.log_file = os.path.join(self.log_dir, f"frontier_elite_{timestamp}.log")
        
        # Messaggio iniziale
        self._write(f"=== FRONTIER ELITE 2 ASCII EDITION - LOG STARTED AT {timestamp} ===")
    
    def _write(self, message):
        """Scrive un messaggio nel file di log."""
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(f"{message}\n")
            
    def _format_message(self, level, message):
        """Formatta un messaggio di log con timestamp, livello e origine."""
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        
        # Ottieni informazioni su chi ha chiamato il logger
        frame = inspect.currentframe().f_back.f_back
        module = inspect.getmodule(frame)
        module_name = module.__name__ if module else "unknown"
        line_no = frame.f_lineno
        
        return f"[{timestamp}] {level.name:8} [{module_name}:{line_no}] {message}"
    
    def log(self, level, message):
        """Registra un messaggio con il livello specificato."""
        if level.value >= self.log_level.value:
            formatted = self._format_message(level, message)
            self._write(formatted)
            if self.console_output:
                print(formatted)
    
    def debug(self, message):
        """Registra un messaggio di debug."""
        self.log(LogLevel.DEBUG, message)
    
    def info(self, message):
        """Registra un messaggio informativo."""
        self.log(LogLevel.INFO, message)
    
    def warning(self, message):
        """Registra un avviso."""
        self.log(LogLevel.WARNING, message)
    
    def error(self, message):
        """Registra un errore."""
        self.log(LogLevel.ERROR, message)
    
    def critical(self, message):
        """Registra un errore critico."""
        self.log(LogLevel.CRITICAL, message)

# Istanza globale del logger
_logger = None

def get_logger():
    """Restituisce l'istanza globale del logger."""
    global _logger
    if _logger is None:
        _logger = Logger()
    return _logger
