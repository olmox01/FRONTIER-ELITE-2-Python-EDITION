"""
Gestisce le navi, inclusa la nave del giocatore
"""
import math
from .vector import Vector3D, Orientation
from .logger import get_logger
from .event_system import get_event_system, GameEventType

logger = get_logger()
event_system = get_event_system()

class Ship:
    def __init__(self, position=None, model=None):
        self.position = position or Vector3D()
        self.orientation = Orientation()
        self.speed = 0.0
        self.model = model or []  # Lista di coppie di punti (linee)
        logger.debug(f"Nave creata alla posizione {self.position.x}, {self.position.y}, {self.position.z}")
        self.mass = 1000.0  # Massa in kg
        self.type = "ship"  # Tipo per il sistema fisico
        self.velocity = Vector3D()  # Vettore velocità
        self.drag_coefficient = 0.0001  # Coefficiente d'attrito spaziale (minimo)
    
    def update(self, delta_time):
        """Aggiorna la posizione della nave in base alla velocità."""
        old_position = Vector3D(self.position.x, self.position.y, self.position.z)
        forward = self.orientation.get_forward_vector()
        movement = forward.scale(self.speed * delta_time)
        self.position = self.position.add(movement)
        
        # Applica l'attrito spaziale (quasi zero)
        if self.speed > 0:
            drag = self.speed * self.speed * self.drag_coefficient * delta_time
            self.speed = max(0, self.speed - drag)
        
        # Pubblica evento movimento se la nave si è spostata significativamente
        if old_position.distance(self.position) > 0.01:
            event_system.publish(GameEventType.PLAYER_MOVE, {
                'ship': self,
                'old_position': old_position,
                'new_position': self.position,
                'speed': self.speed
            })


class PlayerShip(Ship):
    def __init__(self):
        # Creiamo un semplice modello wireframe di una nave
        # Ogni linea è definita da due punti 3D relativi al centro della nave
        cobra_model = [
            # Corpo principale
            [Vector3D(-1, 0, 0), Vector3D(1, 0, 0)],    # Linea centrale
            [Vector3D(1, 0, 0), Vector3D(1, 0, -2)],    # Dal centro alla punta
            [Vector3D(1, 0, -2), Vector3D(-1, 0, 0)],   # Dalla punta alla coda
            
            # Ali
            [Vector3D(-1, 0, 0), Vector3D(-2, 1, 1)],   # Coda all'ala sinistra
            [Vector3D(-1, 0, 0), Vector3D(-2, -1, 1)],  # Coda all'ala destra
            [Vector3D(-2, 1, 1), Vector3D(-2, -1, 1)],  # Connessione ali
            
            # Cabina
            [Vector3D(0, 0.5, -1), Vector3D(0.5, 0.5, -1.5)],  # Tetto cabina
            [Vector3D(0.5, 0.5, -1.5), Vector3D(0.5, -0.5, -1.5)],  # Fronte cabina
            [Vector3D(0.5, -0.5, -1.5), Vector3D(0, -0.5, -1)],  # Base cabina
            [Vector3D(0, -0.5, -1), Vector3D(0, 0.5, -1)],  # Retro cabina
        ]
        
        super().__init__(Vector3D(0, 0, 5), cobra_model)
        logger.info("Nave del giocatore inizializzata")
        
        # Proprietà specifiche del giocatore
        self.max_speed = 100.0  # Velocità massima aumentata
        self.acceleration = 10.0  # Accelerazione aumentata
        self.fuel = 100.0
        self.max_fuel = 100.0
        self.credits = 1000
        self.cargo = {}
        self.cargo_capacity = 20
        self.shields = 100.0
        self.max_shields = 100.0
        self.hull = 100.0
        self.max_hull = 100.0
        
        # Equipaggiamento
        self.has_docking_computer = True
        self.has_fuel_scoop = False
        self.has_ecm = False
        
        # Armi
        self.weapons = ["Laser a impulsi"]
        
    def update(self, delta_time, key=None):
        """Aggiorna la nave del giocatore in base all'input utente."""
        super().update(delta_time)
        
        # Consuma carburante in base alla velocità
        if self.speed > 0:
            fuel_consumption = self.speed * delta_time * 0.01
            self.fuel = max(0, self.fuel - fuel_consumption)
            
        # Se key è specificato, possiamo usarlo per altri comportamenti specifici
        # Al momento non utilizziamo key qui perché la gestione dell'input è in game_state.py
    
    def accelerate(self, amount):
        """Accelera la nave."""
        old_speed = self.speed
        
        if self.fuel > 0:
            self.speed = max(0, min(self.max_speed, self.speed + amount))
        else:
            # Niente carburante, decelera
            self.speed = max(0, self.speed - 0.1)
            
        # Pubblica evento se la velocità è cambiata
        if old_speed != self.speed:
            event_system.publish(GameEventType.PLAYER_MOVE, {
                'ship': self,
                'old_speed': old_speed,
                'new_speed': self.speed,
                'acceleration': amount
            })
    
    def rotate(self, pitch, yaw, roll):
        """Ruota la nave."""
        self.orientation.rotate(pitch, yaw, roll)
    
    def fire_weapon(self):
        """Spara l'arma primaria."""
        if not self.weapons:
            return False
            
        # Logica armi (da implementare)
        weapon = self.weapons[0]
        
        # Pubblica evento
        event_system.publish(GameEventType.PLAYER_FIRE, {
            'ship': self,
            'weapon': weapon,
            'position': self.position,
            'direction': self.orientation.get_forward_vector()
        })
        
        return True
    
    def dock(self, station):
        """Attracca alla stazione."""
        # Logica di attracco
        pass
    
    def jump_to_system(self, target_system):
        """Salta a un altro sistema stellare."""
        distance = self.position.distance(target_system.position)
        fuel_needed = distance * 0.1
        
        if self.fuel >= fuel_needed:
            old_system = None  # Ci vorrebbe un riferimento al sistema corrente
            self.fuel -= fuel_needed
            self.position = Vector3D(target_system.position.x, 
                                    target_system.position.y, 
                                    target_system.position.z)
            logger.info(f"Salto iperspaziale completato verso {target_system.name}. Carburante rimasto: {self.fuel:.1f}")
            
            # Pubblica evento di salto
            event_system.publish(GameEventType.PLAYER_JUMP, {
                'ship': self,
                'from_system': old_system,
                'to_system': target_system,
                'fuel_used': fuel_needed,
                'fuel_remaining': self.fuel
            })
            
            return True
        
        logger.warning(f"Carburante insufficiente per il salto verso {target_system.name}")
        return False
    
    def buy_cargo(self, item, quantity, price_per_unit):
        """Compra merci."""
        total_cost = quantity * price_per_unit
        
        # Verifica spazio nel cargo e crediti disponibili
        current_cargo = sum(self.cargo.values())
        if current_cargo + quantity > self.cargo_capacity:
            return False, "Cargo pieno"
        
        if self.credits < total_cost:
            return False, "Crediti insufficienti"
        
        # Effettua l'acquisto
        self.credits -= total_cost
        if item in self.cargo:
            self.cargo[item] += quantity
        else:
            self.cargo[item] = quantity
        
        return True, f"Acquistato {quantity} {item}"
    
    def sell_cargo(self, item, quantity, price_per_unit):
        """Vende merci."""
        if item not in self.cargo or self.cargo[item] < quantity:
            return False, "Merce insufficiente"
        
        # Effettua la vendita
        total_price = quantity * price_per_unit
        self.credits += total_price
        self.cargo[item] -= quantity
        
        if self.cargo[item] == 0:
            del self.cargo[item]
        
        return True, f"Venduto {quantity} {item} per {total_price} cr"
    
    def take_damage(self, amount, source=None):
        """Subisce danni."""
        if self.shields > 0:
            # Prima assorbono gli scudi
            shield_damage = min(self.shields, amount)
            self.shields -= shield_damage
            remaining_damage = amount - shield_damage
            
            # Effetto visivo per impatto su scudi
            if shield_damage > 0:
                event_system.publish(GameEventType.NOTIFICATION, {
                    'message': f"Impatto sugli scudi: -{shield_damage:.1f}",
                    'color': 4  # Blu per gli scudi
                })
        else:
            remaining_damage = amount
            
        # Il resto va allo scafo
        if remaining_damage > 0:
            old_hull = self.hull
            self.hull = max(0, self.hull - remaining_damage)
            
            # Effetto visivo per impatto sullo scafo
            event_system.publish(GameEventType.NOTIFICATION, {
                'message': f"Danno allo scafo: -{remaining_damage:.1f}",
                'color': 1  # Rosso per i danni
            })
            
            # Pubblica evento danno
            event_system.publish(GameEventType.PLAYER_DAMAGE, {
                'ship': self,
                'old_hull': old_hull,
                'new_hull': self.hull,
                'damage': amount,
                'source': source
            })
            
            # Controlla se la nave è distrutta
            if self.hull <= 0:
                event_system.publish(GameEventType.PLAYER_DEATH, {
                    'ship': self,
                    'cause': 'hull_breach',
                    'source': source
                })
                
        return self.hull > 0
