"""
Sistema di eventi per la comunicazione tra componenti
Implementa un pattern publisher-subscriber per ridurre l'accoppiamento tra moduli
"""
import enum
from typing import Dict, List, Callable, Any, Set, Optional
import weakref
from .logger import get_logger

logger = get_logger()

class GameEventType(enum.Enum):
    """Tipi di eventi supportati dal sistema."""
    # Eventi di gioco
    GAME_START = "game_start"
    GAME_PAUSE = "game_pause"
    GAME_RESUME = "game_resume"
    GAME_EXIT = "game_exit"
    GAME_SAVE = "game_save"
    GAME_LOAD = "game_load"
    
    # Eventi relativi al giocatore
    PLAYER_MOVE = "player_move"
    PLAYER_DAMAGE = "player_damage"
    PLAYER_DEATH = "player_death"
    PLAYER_JUMP = "player_jump"
    PLAYER_DOCK = "player_dock"
    PLAYER_UNDOCK = "player_undock"
    PLAYER_FIRE = "player_fire"
    PLAYER_BUY = "player_buy"
    PLAYER_SELL = "player_sell"
    
    # Eventi UI
    VIEW_CHANGE = "view_change"
    MENU_OPEN = "menu_open"
    MENU_CLOSE = "menu_close"
    DIALOG_OPEN = "dialog_open"
    DIALOG_CLOSE = "dialog_close"
    NOTIFICATION = "notification"
    CONFIG_CHANGED = "config_changed"  # Nuovo evento per le modifiche alla configurazione
    
    # Eventi sistema
    SYSTEM_LOW_MEMORY = "system_low_memory"
    SYSTEM_ERROR = "system_error"
    
    # Eventi universo
    SYSTEM_ENTERED = "system_entered"
    SYSTEM_EXITED = "system_exited"
    OBJECT_SPAWNED = "object_spawned"
    OBJECT_DESTROYED = "object_destroyed"


# Tipo per i callback degli eventi
EventCallback = Callable[[GameEventType, Any], None]


class EventSystem:
    """Sistema di gestione eventi basato su publisher-subscriber."""
    
    def __init__(self):
        """Inizializza il sistema di eventi."""
        # Dizionario di listener per tipo di evento
        self._listeners: Dict[GameEventType, List[weakref.WeakMethod]] = {}
        # Set di listener globali che ricevono tutti gli eventi
        self._global_listeners: Set[weakref.WeakMethod] = set()
        
        logger.info("Sistema di eventi inizializzato")
    
    def subscribe(self, event_type: GameEventType, callback: EventCallback) -> None:
        """
        Sottoscrive un listener a un tipo di evento specifico.
        
        Args:
            event_type: Il tipo di evento a cui sottoscriversi
            callback: Funzione da chiamare quando l'evento viene pubblicato
        """
        if event_type not in self._listeners:
            self._listeners[event_type] = []
        
        # Usa weakref per consentire la garbage collection degli oggetti
        weak_callback = weakref.WeakMethod(callback) if hasattr(callback, '__self__') else weakref.ref(callback)
        
        # Aggiungi il callback se non è già nella lista
        if weak_callback not in self._listeners[event_type]:
            self._listeners[event_type].append(weak_callback)
            logger.debug(f"Listener aggiunto per evento {event_type.name}")
    
    def subscribe_to_all(self, callback: EventCallback) -> None:
        """
        Sottoscrive un listener a tutti i tipi di eventi.
        
        Args:
            callback: Funzione da chiamare quando qualsiasi evento viene pubblicato
        """
        weak_callback = weakref.WeakMethod(callback) if hasattr(callback, '__self__') else weakref.ref(callback)
        self._global_listeners.add(weak_callback)
        logger.debug("Listener globale aggiunto")
    
    def unsubscribe(self, event_type: GameEventType, callback: EventCallback) -> None:
        """
        Rimuove un listener da un tipo di evento specifico.
        
        Args:
            event_type: Il tipo di evento da cui disiscriversi
            callback: Funzione da rimuovere dalla lista dei listener
        """
        if event_type in self._listeners:
            # Cerca il callback nella lista
            to_remove = None
            for weak_ref in self._listeners[event_type]:
                callback_ref = weak_ref()
                if callback_ref and callback_ref == callback:
                    to_remove = weak_ref
                    break
            
            # Rimuovi il callback se trovato
            if to_remove:
                self._listeners[event_type].remove(to_remove)
                logger.debug(f"Listener rimosso per evento {event_type.name}")
    
    def unsubscribe_from_all(self, callback: EventCallback) -> None:
        """
        Rimuove un listener da tutti gli eventi.
        
        Args:
            callback: Funzione da rimuovere
        """
        # Cerca il callback nei listener globali
        to_remove = None
        for weak_ref in self._global_listeners:
            callback_ref = weak_ref()
            if callback_ref and callback_ref == callback:
                to_remove = weak_ref
                break
        
        # Rimuovi il callback se trovato
        if to_remove:
            self._global_listeners.remove(to_remove)
            logger.debug("Listener globale rimosso")
        
        # Rimuovi anche da tutti i tipi di eventi specifici
        for event_type in GameEventType:
            self.unsubscribe(event_type, callback)
    
    def publish(self, event_type: GameEventType, data: Optional[Any] = None) -> None:
        """
        Pubblica un evento a tutti i listener sottoscritti.
        
        Args:
            event_type: Il tipo di evento da pubblicare
            data: Dati aggiuntivi da passare ai listener
        """
        logger.debug(f"Evento pubblicato: {event_type.name}")
        
        # Chiama tutti i listener per questo tipo di evento
        if event_type in self._listeners:
            dead_refs = []
            
            for weak_ref in self._listeners[event_type]:
                callback = weak_ref()
                if callback:
                    try:
                        callback(event_type, data)
                    except Exception as e:
                        logger.error(f"Errore nel callback per evento {event_type.name}: {str(e)}")
                else:
                    # Il callback è stato raccolto dal garbage collector
                    dead_refs.append(weak_ref)
            
            # Rimuovi i riferimenti morti
            for dead_ref in dead_refs:
                if dead_ref in self._listeners[event_type]:
                    self._listeners[event_type].remove(dead_ref)
        
        # Chiama anche i listener globali
        dead_global_refs = []
        for weak_ref in self._global_listeners:
            callback = weak_ref()
            if callback:
                try:
                    callback(event_type, data)
                except Exception as e:
                    logger.error(f"Errore nel callback globale per evento {event_type.name}: {str(e)}")
            else:
                # Il callback è stato raccolto dal garbage collector
                dead_global_refs.append(weak_ref)
        
        # Rimuovi i riferimenti morti
        for dead_ref in dead_global_refs:
            if dead_ref in self._global_listeners:
                self._global_listeners.remove(dead_ref)
    
    def clear_all_listeners(self) -> None:
        """Rimuove tutti i listener registrati."""
        self._listeners.clear()
        self._global_listeners.clear()
        logger.debug("Tutti i listener sono stati rimossi")


# Istanza globale del sistema di eventi
_event_system = None

def get_event_system() -> EventSystem:
    """Restituisce l'istanza globale del sistema di eventi."""
    global _event_system
    if _event_system is None:
        _event_system = EventSystem()
    return _event_system
