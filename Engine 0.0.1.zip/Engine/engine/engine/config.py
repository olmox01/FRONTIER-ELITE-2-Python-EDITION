"""
Sistema di configurazione per Frontier Elite 2 ASCII Edition
"""
import os
import json
import time
from .logger import get_logger, LogLevel

logger = get_logger()

class ConfigManager:
    """Gestisce la configurazione del gioco da file JSON."""
    
    DEFAULT_CONFIG = {
        "logging": {
            "level": "INFO",
            "console_output": True,
            "log_dir": "logs"
        },
        "graphics": {
            "density_chars": " .:-=+*#%@",
            "extended_chars": " .,:;i1tfLCG08@",
            "stars_visible": 1000,
            "fov": 60,
            "render_distance": 500.0,
            "render_wireframe": True,
            "use_z_buffer": True,
            "frustum_culling": True,
            "show_starmap_grid": True,
            "extended_color_support": True
        },
        "gameplay": {
            "auto_save_interval": 300,  # secondi
            "target_fps": 30,
            "show_fps": True,
            "max_delta_time": 0.1,  # Limite per delta time
            "difficulty": "normal"  # easy, normal, hard
        },
        "ui": {
            "refresh_rate": 30,  # Hz
            "message_duration": 5.0,  # secondi
            "show_debug_info": False,
            "hud_style": "compact"  # compact, full, minimal
        },
        "audio": {
            "enabled": False,
            "music_volume": 0.5,
            "sfx_volume": 0.7
        },
        "controls": {
            "mouse_sensitivity": 1.0,
            "invert_y": True,
            "key_repeat_delay": 0.15
        },
        "advanced": {
            "precision_math": True,
            "gpu_acceleration": False,
            "multi_threading": False,
            "memory_limit_mb": 128
        }
    }
    
    def __init__(self, config_file="config.json"):
        """Inizializza il gestore di configurazione."""
        self.config_file = config_file
        self.config = self.DEFAULT_CONFIG.copy()
        self.last_modified = 0
        self.load_config()
        logger.info("Sistema di configurazione inizializzato")
    
    def load_config(self):
        """Carica la configurazione da file."""
        try:
            if os.path.exists(self.config_file):
                # Controlla se il file è stato modificato dall'ultimo caricamento
                file_mtime = os.path.getmtime(self.config_file)
                if file_mtime <= self.last_modified:
                    return  # File non modificato
                    
                self.last_modified = file_mtime
                
                with open(self.config_file, "r", encoding="utf-8") as f:
                    user_config = json.load(f)
                    
                # Aggiorna la config con i valori dell'utente
                self._update_nested_dict(self.config, user_config)
                logger.info(f"Configurazione caricata da {self.config_file}")
            else:
                self.save_config()
                logger.info(f"File di configurazione {self.config_file} non trovato, creato nuovo file")
        except Exception as e:
            logger.error(f"Errore nel caricamento della configurazione: {str(e)}")
    
    def _update_nested_dict(self, d, u):
        """Aggiorna un dizionario in modo ricorsivo."""
        for k, v in u.items():
            if isinstance(v, dict) and k in d and isinstance(d[k], dict):
                self._update_nested_dict(d[k], v)
            else:
                d[k] = v
    
    def save_config(self):
        """Salva la configurazione su file."""
        try:
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=4)
            self.last_modified = time.time()
            logger.info(f"Configurazione salvata in {self.config_file}")
        except Exception as e:
            logger.error(f"Errore nel salvataggio della configurazione: {str(e)}")
    
    def get(self, key, default=None):
        """Ottiene un valore di configurazione con supporto per percorsi nidificati."""
        keys = key.split(".")
        value = self.config
        try:
            for k in keys:
                value = value[k]
            return value
        except (KeyError, TypeError):
            logger.debug(f"Chiave di configurazione non trovata: {key}, uso valore di default: {default}")
            return default
    
    def set(self, key, value):
        """Imposta un valore di configurazione con supporto per percorsi nidificati."""
        keys = key.split(".")
        config = self.config
        
        # Naviga nella gerarchia fino all'ultima chiave
        for k in keys[:-1]:
            if k not in config or not isinstance(config[k], dict):
                config[k] = {}
            config = config[k]
            
        # Imposta il valore
        config[keys[-1]] = value
        logger.debug(f"Impostato {key} = {value}")
    
    def reload(self):
        """Ricarica la configurazione dal file."""
        self.load_config()

# Istanza globale del gestore di configurazione
_config_manager = None

def get_config():
    """Restituisce l'istanza globale del gestore di configurazione."""
    global _config_manager
    if _config_manager is None:
        _config_manager = ConfigManager()
    return _config_manager
