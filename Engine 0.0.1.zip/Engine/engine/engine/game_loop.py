"""
Game Loop ottimizzato per Frontier Elite 2 ASCII Edition
Fornisce un ciclo di gioco stabile con delta time variabile
"""
import time
import statistics
from .logger import get_logger
from .config import get_config

logger = get_logger()

class GameLoop:
    """Game loop ottimizzato con delta time variabile e monitoraggio prestazioni."""
    
    def __init__(self, target_fps=30):
        """Inizializza il game loop."""
        self.target_fps = target_fps
        self.frame_time = 1.0 / target_fps
        self.running = False
        self.last_time = 0
        self.delta_time = 0
        self.accumulated_time = 0
        
        # Carica configurazione
        config = get_config()
        self.max_delta_time = config.get("gameplay.max_delta_time", 0.1)
        
        # Monitoraggio prestazioni
        self.fps_history = []
        self.frame_times = []
        self.fps_update_interval = 1.0  # Aggiorna FPS ogni secondo
        self.last_fps_update = 0
        self.frames_this_second = 0
        self.total_frames = 0
        
        logger.info(f"Game Loop inizializzato con target FPS: {target_fps}")
    
    def start(self):
        """Avvia il game loop."""
        self.running = True
        self.last_time = time.time()
        self.last_fps_update = time.time()
        logger.info("Game Loop avviato")
        
    def stop(self):
        """Ferma il game loop."""
        self.running = False
        logger.info("Game Loop fermato")
    
    def should_continue(self):
        """Verifica se il loop deve continuare."""
        return self.running
    
    def begin_frame(self):
        """Inizia un nuovo frame e calcola il delta time."""
        current_time = time.time()
        self.delta_time = current_time - self.last_time
        self.last_time = current_time
        
        # Limita il delta time per evitare salti troppo grandi
        self.delta_time = min(self.delta_time, self.max_delta_time)
        
        # Incrementa contatori frame
        self.frames_this_second += 1
        self.total_frames += 1
        
        return self.delta_time
    
    def end_frame(self):
        """Gestisce la fine del frame e la sincronizzazione."""
        # Calcola quanto tempo è trascorso dall'inizio del frame
        frame_elapsed = time.time() - self.last_time
        
        # Calcola quanto tempo dovrebbe attendere
        sleep_time = max(0, self.frame_time - frame_elapsed)
        
        # Dormi solo se necessario
        if sleep_time > 0.001:  # Evita sleep troppo brevi
            time.sleep(sleep_time)
        
        # Aggiorna le statistiche FPS
        current_time = time.time()
        frame_time = current_time - self.last_time + sleep_time
        self.frame_times.append(frame_time)
        
        # Limita la dimensione dell'array delle prestazioni
        if len(self.frame_times) > 100:
            self.frame_times.pop(0)
        
        # Aggiorna FPS periodicamente
        if current_time - self.last_fps_update > self.fps_update_interval:
            if self.frame_times:
                avg_frame_time = statistics.mean(self.frame_times)
                current_fps = 1.0 / avg_frame_time if avg_frame_time > 0 else 0
                self.fps_history.append(current_fps)
                
                # Limita la dimensione della cronologia FPS
                if len(self.fps_history) > 10:
                    self.fps_history.pop(0)
                
                logger.debug(f"FPS corrente: {current_fps:.1f}")
            
            self.last_fps_update = current_time
            self.frame_times.clear()
    
    def get_current_fps(self):
        """Restituisce l'FPS corrente."""
        if not self.fps_history:
            return self.target_fps
        return self.fps_history[-1]
    
    def get_average_fps(self):
        """Restituisce l'FPS medio."""
        if not self.fps_history:
            return self.target_fps
        return statistics.mean(self.fps_history)
    
    def set_target_fps(self, fps):
        """Imposta un nuovo target FPS."""
        self.target_fps = fps
        self.frame_time = 1.0 / fps
        logger.info(f"Target FPS impostato a {fps}")
