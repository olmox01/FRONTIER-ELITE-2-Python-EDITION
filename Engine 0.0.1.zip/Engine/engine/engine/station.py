"""
Definizione della classe Station per le stazioni spaziali
"""
from .vector import Vector3D
from .logger import get_logger
from .event_system import get_event_system, GameEventType
from .memory_manager import get_memory_manager

logger = get_logger()
event_system = get_event_system()
memory_manager = get_memory_manager()

class Station:
    def __init__(self, position, name):
        self.position = position
        self.name = name
        self.services = {
            "mercato": True,
            "riparazioni": True,
            "rifornimento": True,
            "missioni": True
        }
        self.prices = self._generate_prices()
        logger.debug(f"Stazione {name} inizializzata alla posizione {position.x}, {position.y}, {position.z}")
    
    def _generate_prices(self):
        """Genera prezzi casuali per le merci."""
        # Usa la cache se esistente
        cache_key = f"station_prices_{self.name}"
        cached_prices = memory_manager.get_cached_data(cache_key)
        if cached_prices:
            logger.debug(f"Prezzi caricati dalla cache per stazione {self.name}")
            return cached_prices
            
        prices = {
            "Cibo": {"buy": 25, "sell": 20},
            "Tessuti": {"buy": 35, "sell": 30},
            "Minerali": {"buy": 80, "sell": 70},
            "Liquori": {"buy": 120, "sell": 100},
            "Tecnologia": {"buy": 200, "sell": 180},
            "Armi": {"buy": 300, "sell": 270},
            "Medicinali": {"buy": 150, "sell": 135}
        }
        
        # Salva nella cache per riutilizzo
        memory_manager.cache_data(cache_key, prices)
        return prices
    
    def dock(self, ship):
        """Permette a una nave di attraccare alla stazione."""
        logger.info(f"Nave in attracco alla stazione {self.name}")
        
        # Pubblica evento di attracco
        event_system.publish(GameEventType.PLAYER_DOCK, {
            'ship': ship,
            'station': self
        })
        
        return True
    
    def buy_from_ship(self, ship, item, quantity):
        """La stazione compra merci dalla nave."""
        if item not in self.prices:
            logger.warning(f"Tentativo di vendere {item} non scambiato alla stazione {self.name}")
            return False, f"{item} non è scambiato qui"
        
        if item not in ship.cargo or ship.cargo[item] < quantity:
            return False, "Merce insufficiente"
        
        # Completa la transazione
        total = quantity * self.prices[item]["sell"]
        ship.credits += total
        ship.cargo[item] -= quantity
        
        if ship.cargo[item] == 0:
            del ship.cargo[item]
            
        # Pubblica evento di vendita
        event_system.publish(GameEventType.PLAYER_SELL, {
            'ship': ship,
            'station': self,
            'item': item,
            'quantity': quantity,
            'total': total
        })
        
        logger.info(f"Venduto {quantity} {item} per {total} cr alla stazione {self.name}")
        return True, f"Venduto {quantity} {item} per {total} cr"
    
    def sell_to_ship(self, ship, item, quantity):
        """La stazione vende merci alla nave."""
        if item not in self.prices:
            logger.warning(f"Tentativo di acquistare {item} non scambiato dalla stazione {self.name}")
            return False, f"{item} non è scambiato qui"
        
        # Controlla spazio e crediti
        if sum(ship.cargo.values()) + quantity > ship.cargo_capacity:
            return False, "Cargo insufficiente"
        
        total = quantity * self.prices[item]["buy"]
        if ship.credits < total:
            return False, "Crediti insufficienti"
        
        # Completa la transazione
        ship.credits -= total
        if item in ship.cargo:
            ship.cargo[item] += quantity
        else:
            ship.cargo[item] = quantity
            
        # Pubblica evento di acquisto
        event_system.publish(GameEventType.PLAYER_BUY, {
            'ship': ship,
            'station': self,
            'item': item,
            'quantity': quantity,
            'total': total
        })
        
        logger.info(f"Acquistato {quantity} {item} per {total} cr dalla stazione {self.name}")
        return True, f"Acquistato {quantity} {item} per {total} cr"
