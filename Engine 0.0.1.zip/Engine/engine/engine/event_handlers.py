"""
Gestori di eventi di esempio per Frontier Elite 2 ASCII Edition
Dimostra come utilizzare il sistema di eventi per vari scopi
"""
import time  # Aggiungiamo l'import mancante
from .logger import get_logger
from .event_system import get_event_system, GameEventType

logger = get_logger()
event_system = get_event_system()

class GameEventLogger:
    """
    Esempio di classe che registra eventi di gioco.
    Può essere utilizzata per debugging, analisi o implementazione di achievement.
    """
    
    def __init__(self):
        """Inizializza il logger di eventi e si sottoscrive agli eventi rilevanti."""
        # Sottoscrizione agli eventi di gioco
        event_system.subscribe(GameEventType.GAME_START, self.on_game_event)
        event_system.subscribe(GameEventType.GAME_EXIT, self.on_game_event)
        event_system.subscribe(GameEventType.PLAYER_JUMP, self.on_player_jump)
        event_system.subscribe(GameEventType.PLAYER_DOCK, self.on_player_dock)
        event_system.subscribe(GameEventType.PLAYER_DAMAGE, self.on_player_damage)
        event_system.subscribe(GameEventType.PLAYER_DEATH, self.on_player_death)
        
        # Statistiche di gioco
        self.jump_count = 0
        self.dock_count = 0
        self.damage_taken = 0
        self.start_time = None
    
    def on_game_event(self, event_type, data):
        """Gestisce eventi generali di gioco."""
        if event_type == GameEventType.GAME_START:
            # Verifica se data è un dizionario o ha l'attributo 'time'
            if isinstance(data, dict):
                self.start_time = data.get('time', None)
            else:
                # Se è un oggetto GameState, imposta start_time a time.time()
                self.start_time = time.time()
            logger.info(f"Nuova sessione di gioco iniziata")
        elif event_type == GameEventType.GAME_EXIT:
            logger.info(f"Sessione di gioco terminata. Statistiche: "
                      f"Salti: {self.jump_count}, Docking: {self.dock_count}, "
                      f"Danni subiti: {self.damage_taken}")
    
    def on_player_jump(self, event_type, data):
        """Gestisce eventi di salto iperspaziale."""
        ship = data.get('ship', None)
        target = data.get('to_system', None)
        
        if ship and target:
            self.jump_count += 1
            logger.info(f"Salto iperspaziale verso {target.name} completato "
                      f"(#{self.jump_count})")
    
    def on_player_dock(self, event_type, data):
        """Gestisce eventi di attracco a stazioni."""
        ship = data.get('ship', None)
        station = data.get('station', None)
        
        if ship and station:
            self.dock_count += 1
            logger.info(f"Attracco a {station.name} completato "
                      f"(#{self.dock_count})")
    
    def on_player_damage(self, event_type, data):
        """Gestisce eventi di danno al giocatore."""
        damage = data.get('damage', 0)
        self.damage_taken += damage
        new_hull = data.get('new_hull', 0)
        
        if new_hull < 30:
            logger.warning(f"AVVISO: Integrità scafo critica ({new_hull:.1f}%)!")
    
    def on_player_death(self, event_type, data):
        """Gestisce eventi di morte del giocatore."""
        cause = data.get('cause', 'unknown')
        logger.critical(f"Nave distrutta! Causa: {cause}")

# Crea un'istanza del logger di eventi all'avvio
game_event_logger = GameEventLogger()


class AutoSaveHandler:
    """
    Esempio di gestore che attiva il salvataggio automatico su eventi specifici.
    """
    
    def __init__(self):
        """Inizializza il gestore di salvataggio automatico."""
        # Sottoscrizione agli eventi che attivano il salvataggio
        event_system.subscribe(GameEventType.PLAYER_JUMP, self.trigger_autosave)
        event_system.subscribe(GameEventType.PLAYER_DOCK, self.trigger_autosave)
        event_system.subscribe(GameEventType.SYSTEM_ENTERED, self.trigger_autosave)
    
    def trigger_autosave(self, event_type, data):
        """Attiva il salvataggio automatico."""
        logger.debug(f"Salvataggio automatico attivato da evento {event_type.name}")
        # Qui andrebbe richiamato il salvataggio effettivo
        event_system.publish(GameEventType.GAME_SAVE, {'type': 'auto', 'trigger': event_type.name})

# Crea un'istanza del gestore di salvataggio automatico all'avvio
auto_save_handler = AutoSaveHandler()
