"""
Renderer ASCII ottimizzato per visualizzare grafica vettoriale 3D nel terminale
Con supporto per rendering avanzato e compatibilità futura con 256 colori
"""
import curses
import math
import time
import numpy as np
from .vector import Vector3D, Matrix3D
from .logger import get_logger
from .memory_manager import get_memory_manager
from .event_system import get_event_system, GameEventType
from .config import get_config
import random
try:
    import colorama
    from colorama import Fore, Back, Style
    COLORAMA_AVAILABLE = True
    colorama.init()
except ImportError:
    COLORAMA_AVAILABLE = False

logger = get_logger()
memory_manager = get_memory_manager()
event_system = get_event_system()
config = get_config()

class RenderVertex:
    """Rappresentazione di un vertice per rendering avanzato."""
    def __init__(self, position, color=7, char='*', z_depth=0.0):
        self.position = position  # Vector3D
        self.color = color        # Colore
        self.char = char          # Carattere da visualizzare
        self.z_depth = z_depth    # Profondità Z per sorting
        self.screen_x = 0         # Posizione proiettata X
        self.screen_y = 0         # Posizione proiettata Y
        
class ASCIIRenderer:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.aspect = width / (height * 2)  # Caratteri ASCII più alti che larghi
        self.fov = config.get("graphics.fov", 60)
        self.z_near = 0.1
        self.z_far = 1000.0
        self.render_distance = config.get("graphics.render_distance", 500.0)
        
        # Caratteri per densità con diversi livelli di dettaglio
        self.density_chars = config.get("graphics.density_chars", " .:-=+*#%@")
        self.extended_chars = config.get("graphics.extended_chars", " .,:;i1tfLCG08@")
        
        # Z-buffer per corretto ordinamento in profondità
        self.z_buffer = None
        self.vertex_buffer = []
        
        # Framerate e ottimizzazioni
        self.last_render_time = 0
        self.last_frame_count = 0
        self.total_frames = 0
        self.frame_time = 0
        
        # Cache per calcoli costosi
        self.projection_cache = {}
        self.transform_cache = {}
        self.scene_cache = {}
        
        # Stati di rendering
        self.render_wireframe = config.get("graphics.render_wireframe", True)
        self.use_z_buffer = config.get("graphics.use_z_buffer", True)
        self.frustum_culling = config.get("graphics.frustum_culling", True)
        
        # Supporto a colori avanzati
        self.use_256_colors = False
        self.advanced_color_lookup = {}
        self._init_extended_colors()
        
        # Sottoscrivi agli eventi di configurazione
        event_system.subscribe(GameEventType.CONFIG_CHANGED, self.on_config_changed)
        
        logger.info(f"Renderer inizializzato con dimensioni {width}x{height}, FOV {self.fov}°")
        
        # Caratteri stellari migliorati
        self.STAR_CHARS = ['★', '⭑', '·', '*', '✧', '✦', '+']
        # Colori per stelle (oltre il bianco)
        self.STAR_COLORS = [7, 3, 6, 5, 4, 1]  # Bianco(7), Giallo(3), Ciano(6), Magenta(5), Blu(4), Rosso(1)
        
        # Caratteri per pixel art
        self.PIXEL_CHARS = {
            'full': '█',       # Blocco pieno
            'upper_half': '▀', # Metà superiore
            'lower_half': '▄', # Metà inferiore
            'left_half': '▌',  # Metà sinistra
            'right_half': '▐', # Metà destra
            'light': '░',      # Ombreggiatura leggera
            'medium': '▒',     # Ombreggiatura media
            'dark': '▓',       # Ombreggiatura scura
            'transparent': '·' # Punto per trasparenza
        }
    
    def _init_extended_colors(self):
        """Inizializza il supporto per 256 colori se disponibile."""
        try:
            if curses.can_change_color() and curses.COLORS >= 256:
                self.use_256_colors = True
                # Crea mappatura colori avanzati
                for i in range(16, 32):
                    # Mapping per gradienti da usare in futuro
                    self.advanced_color_lookup[i-16] = i
                logger.info("Supporto 256 colori abilitato")
            else:
                logger.info("256 colori non disponibili, usando colori base")
        except Exception as e:
            logger.warning(f"Errore nell'inizializzazione colori estesi: {e}")
    
    def _init_z_buffer(self):
        """Inizializza lo z-buffer per il rendering corretto in profondità."""
        if self.use_z_buffer:
            self.z_buffer = np.full((self.height, self.width), float('inf'), dtype=np.float32)
            self.char_buffer = np.full((self.height, self.width), ' ', dtype=np.str_)  # Corretto per NumPy 2.0
            self.color_buffer = np.zeros((self.height, self.width), dtype=np.int16)
    
    def project_point(self, point):
        """Proietta un punto 3D su uno schermo 2D con cache."""
        # Usa la cache per punti già proiettati
        point_key = f"{point.x:.2f},{point.y:.2f},{point.z:.2f}"
        cached = memory_manager.get_cached_data(f"proj_{point_key}")
        if cached:
            return cached
        
        # Punti troppo vicini causano problemi di proiezione
        if point.z <= self.z_near:
            return (-1, -1)  # Fuori schermo
            
        # Per punti troppo lontani, evitiamo di proiettare
        if point.z > self.render_distance:
            return (-1, -1)  # Fuori schermo
        
        # Calcolo proiezione prospettica ottimizzato
        f = 1.0 / math.tan(math.radians(self.fov) / 2.0)
        
        # Matrice di proiezione semplificata
        x = point.x * f / (point.z * self.aspect)
        y = point.y * f / point.z
        
        # Trasformazione in coordinate schermo
        screen_x = int((x + 1.0) * self.width / 2.0)
        screen_y = int((1.0 - y) * self.height / 2.0)
        
        # Controllo limiti dello schermo
        if screen_x < 0 or screen_x >= self.width or screen_y < 0 or screen_y >= self.height:
            result = (-1, -1)  # Fuori dallo schermo
        else:
            result = (screen_x, screen_y)
        
        # Salva nella cache con TTL di 1 secondo (i punti si muovono)
        memory_manager.cache_data(f"proj_{point_key}", result, ttl=1.0)
        return result

    def draw_line(self, stdscr, start, end, char='*', color_pair=0):
        """Disegna una linea tra due punti 3D con ottimizzazione z-buffer."""
        if start.z <= self.z_near or end.z <= self.z_near:
            return
            
        x0, y0 = self.project_point(start)
        x1, y1 = self.project_point(end)
        
        # Se uno dei punti è fuori schermo, ignoriamo la linea
        if x0 < 0 or y0 < 0 or x1 < 0 or y1 < 0:
            return
        
        # Algoritmo di Bresenham ottimizzato
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy
        
        # Interpolazione Z per z-buffer
        if self.use_z_buffer:
            z0, z1 = start.z, end.z
            z_step = (z1 - z0) / max(1, (dx + dy))
            current_z = z0
        
        while True:
            if 0 <= x0 < self.width and 0 <= y0 < self.height:
                if self.use_z_buffer:
                    # Controlla se questo punto è più vicino di quello già nello z-buffer
                    if current_z < self.z_buffer[y0, x0]:
                        self.z_buffer[y0, x0] = current_z
                        self.char_buffer[y0, x0] = char
                        self.color_buffer[y0, x0] = color_pair
                    current_z += z_step
                else:
                    # Disegna direttamente
                    try:
                        stdscr.addch(y0, x0, char, curses.color_pair(color_pair))
                    except curses.error:
                        pass  # Ignora errori di posizionamento
            
            if x0 == x1 and y0 == y1:
                break
                
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x0 += sx
            if e2 < dx:
                err += dx
                y0 += sy
    
    def render_space(self, stdscr, player, universe, game_state):
        """Renderizza la vista spaziale con tutti i miglioramenti."""
        # Ottimizzazione: verifica se dobbiamo renderizzare questo frame
        current_time = time.time()
        if current_time - self.last_render_time < 1.0/60.0:  # Massimo 60 FPS
            return
            
        self.last_render_time = current_time
        self.total_frames += 1
        
        # Notifica inizio rendering (utile per profiling)
        event_system.publish(GameEventType.NOTIFICATION, {
            'type': 'render_start',
            'view': 'space',
            'frame': self.total_frames
        })
        
        # Inizializza Z-buffer per questo frame
        if self.use_z_buffer:
            self._init_z_buffer()
            self.vertex_buffer = []
        
        render_start = time.time()
        
        # Ottieni TUTTE le stelle visibili (non solo quelle davanti)
        # Rimuoviamo la limitazione del frustum culling per le stelle
        visible_stars = universe.stars
            
        # Ottieni sistema corrente e lista pianeti
        current_system = universe.get_current_system(player.position)
        visible_planets = []
        visible_ships = []
        
        if current_system:
            # Include TUTTI i pianeti, non solo quelli davanti
            visible_planets = current_system.planets
                    
            # Ottieni navi visibili
            visible_ships = universe.get_nearby_ships(player.position)
            
        # Renderizza la barra di stato superiore
        self._render_top_status_bar(stdscr)
        
        # Renderizza le stelle di background con dimensioni variabili in base alla distanza
        for star in visible_stars:
            # Calcola la distanza dalla stella al giocatore
            distance = star.position.subtract(player.position).length()
            
            # Proietta la stella
            rel_pos = star.position.subtract(player.position)
            # Trasforma la posizione in base all'orientamento del giocatore
            transformed = player.orientation.transform_point(rel_pos)
            
            # Ottieni le coordinate schermo dalla posizione trasformata
            screen_x, screen_y = self.project_point(transformed)
            
            if screen_x >= 0 and screen_y >= 0:  # Stelle visibili
                # Stella speciale o standard basato su probabilità
                use_special = random.random() < 0.2  # 20% di stelle colorate
                
                # Scala luminosità e dimensione in base alla distanza
                brightness = min(9, int(star.brightness * 10))
                
                # Scelta del carattere della stella
                if distance < 50:
                    star_char = '★' if use_special else '✦'
                elif distance < 100:
                    star_char = '⭑' if use_special else '*'
                else:
                    star_char = '·' if use_special else '·'
                
                # Scelta del colore (bianco di default, colori speciali per il 20%)
                star_color = random.choice(self.STAR_COLORS) if use_special else 7
                
                if self.use_z_buffer:
                    # Aggiungi al vertex buffer per z-sorting
                    vertex = RenderVertex(transformed, star_color, star_char, transformed.z)
                    vertex.screen_x = screen_x
                    vertex.screen_y = screen_y
                    self.vertex_buffer.append(vertex)
                else:
                    try:
                        # Disegna direttamente
                        stdscr.addch(screen_y, screen_x, star_char, curses.color_pair(star_color))
                    except curses.error:
                        pass
        
        # Renderizza i pianeti visibili
        for planet in visible_planets:
            self.render_planet(stdscr, planet, player)
        
        # Renderizza altre navi
        for ship in visible_ships:
            self.render_ship(stdscr, ship, player)
        
        # Se usiamo z-buffer, disegna i vertici in ordine di profondità
        if self.use_z_buffer:
            # Ordina per z decrescente (dal più lontano al più vicino)
            self.vertex_buffer.sort(key=lambda v: -v.z_depth)
            
            # Disegna i vertici
            for vertex in self.vertex_buffer:
                try:
                    stdscr.addch(vertex.screen_y, vertex.screen_x, 
                                vertex.char, curses.color_pair(vertex.color))
                except curses.error:
                    pass
        
        # Renderizza la dashboard/HUD
        self.render_hud(stdscr, player, game_state)
        
        # Aggiungiamo la renderizzazione del radar
        self.render_radar(stdscr, player, universe, game_state)
        
        # Calcola tempo di rendering
        render_time = (time.time() - render_start) * 1000  # ms
        
        # Notifica fine rendering (utile per profiling)
        event_system.publish(GameEventType.NOTIFICATION, {
            'type': 'render_complete',
            'view': 'space',
            'stats': {
                'visible_stars': len(visible_stars),
                'planets': len(visible_planets),
                'ships': len(visible_ships),
                'render_time_ms': render_time,
                'vertex_count': len(self.vertex_buffer) if self.use_z_buffer else 0
            }
        })
    
    def render_planet(self, stdscr, planet, player):
        """Renderizza un pianeta come una sfera ASCII."""
        rel_pos = planet.position.subtract(player.position)
        transformed = player.orientation.transform_point(rel_pos)
        
        if transformed.z <= self.z_near:
            return  # Dietro al giocatore
        
        radius = planet.radius
        distance = transformed.length()
        
        # Determina la dimensione apparente con formula ottica corretta
        apparent_size = int(radius / distance * self.width / math.tan(math.radians(self.fov/2)) / 2)
        apparent_size = max(1, min(apparent_size, 20))  # Limitato per performance
        
        center_x, center_y = self.project_point(transformed)
        if center_x < 0 or center_y < 0:
            return  # Fuori dallo schermo
        
        # Calcola il raggio in pixel sullo schermo
        pixel_radius = apparent_size
        
        # Ottimizzazione: renderizza solo se visibile
        if (center_x + pixel_radius < 0 or center_x - pixel_radius >= self.width or
            center_y + pixel_radius < 0 or center_y - pixel_radius >= self.height):
            return  # Fuori dallo schermo
        
        # Disegna una semplice rappresentazione del pianeta
        color = planet.get_color()
        
        # Ottimizzazione: se il pianeta è molto piccolo, renderizzalo come un punto
        if apparent_size <= 2:
            if self.use_z_buffer:
                vertex = RenderVertex(transformed, color, self.PIXEL_CHARS['full'], transformed.z)
                vertex.screen_x = center_x
                vertex.screen_y = center_y
                self.vertex_buffer.append(vertex)
            else:
                try:
                    stdscr.addch(center_y, center_x, self.PIXEL_CHARS['full'], curses.color_pair(color))
                except curses.error:
                    pass
            return
            
        # Altrimenti renderizza come sfera con pixel art migliorata
        for y in range(center_y - pixel_radius, center_y + pixel_radius + 1):
            for x in range(center_x - pixel_radius*2, center_x + pixel_radius*2 + 1):
                if 0 <= x < self.width and 0 <= y < self.height:
                    # Compensazione per caratteri rettangolari
                    dx = (x - center_x) / 2
                    dy = y - center_y
                    
                    # Distanza dal centro della sfera
                    dist = math.sqrt(dx*dx + dy*dy)
                    
                    # Se all'interno del raggio della sfera
                    if dist <= pixel_radius:
                        # Calcola l'illuminazione
                        char_idx = min(9, int((dist / pixel_radius) * 10))
                        
                        # Scegli il carattere appropriato basato sulla posizione
                        if char_idx < 3:
                            char = self.PIXEL_CHARS['full']
                        elif char_idx < 5:
                            char = self.PIXEL_CHARS['dark']
                        elif char_idx < 7:
                            char = self.PIXEL_CHARS['medium']
                        else:
                            char = self.PIXEL_CHARS['light']
                        
                        if self.use_z_buffer:
                            # Calcola la profondità per questo pixel della sfera
                            # Usa la formula per la profondità su una sfera
                            depth_offset = math.sqrt(radius*radius - (dist/pixel_radius*radius)**2)
                            point_z = transformed.z - depth_offset
                            
                            vertex = RenderVertex(transformed, color, char, point_z)
                            vertex.screen_x = x
                            vertex.screen_y = y
                            self.vertex_buffer.append(vertex)
                        else:
                            try:
                                stdscr.addch(y, x, char, curses.color_pair(color))
                            except curses.error:
                                pass
    
    def render_ship(self, stdscr, ship, player):
        """Renderizza una nave come un insieme di linee."""
        rel_pos = ship.position.subtract(player.position)
        transformed = player.orientation.transform_point(rel_pos)
        
        if transformed.z <= self.z_near:
            return  # Dietro al giocatore
        
        # Trasforma e disegna ogni linea che definisce la nave
        for line in ship.model:
            start = ship.orientation.transform_point(line[0]).add(transformed)
            end = ship.orientation.transform_point(line[1]).add(transformed)
            
            # Verifica se la linea è nel frustum
            if self.frustum_culling:
                # Semplice test Z
                if start.z <= self.z_near or end.z <= self.z_near:
                    continue
                    
            self.draw_line(stdscr, start, end, '*', 3)  # Giallo
    
    def render_starmap(self, stdscr, player, universe, game_state):
        """Renderizza la mappa stellare con miglioramenti."""
        logger.debug("Rendering mappa stellare")
        
        # Calcolo centro dello schermo
        center_x = self.width // 2
        center_y = self.height // 2
        
        # Scala per la mappa
        scale = game_state.starmap_scale
        
        # Posizione corrente del giocatore
        player_x = center_x
        player_y = center_y
        
        # Disegna una griglia di sfondo
        if config.get("graphics.show_starmap_grid", True):
            # Disegna griglia leggera
            grid_spacing = int(10 * scale)
            if grid_spacing > 0:
                for x in range(grid_spacing, self.width, grid_spacing):
                    for y in range(0, self.height):
                        try:
                            stdscr.addch(y, x, '·', curses.color_pair(8))
                        except curses.error:
                            pass
                            
                for y in range(grid_spacing, self.height, grid_spacing):
                    for x in range(0, self.width):
                        try:
                            stdscr.addch(y, x, '·', curses.color_pair(8))
                        except curses.error:
                            pass
        
        # Disegna i sistemi stellari
        for system in universe.systems:
            # Calcola la posizione relativa
            dx = system.position.x - player.position.x
            dz = system.position.z - player.position.z  # Usiamo Z come Y nella vista 2D della mappa
            
            # Mappa nella griglia 2D
            screen_x = center_x + int(dx * scale)
            screen_y = center_y + int(dz * scale)
            
            # Verifica se il sistema è visibile sullo schermo
            if 0 <= screen_x < self.width and 0 <= screen_y < self.height:
                # Scegli il colore in base al tipo di stella
                color = system.get_star_color()
                
                # Determina il carattere in base al tipo e dimensione della stella
                star_char = '*'
                if system.star_size > 1.5:
                    star_char = 'O'
                elif system.star_size > 0.8:
                    star_char = '*'
                else:
                    star_char = '·'
                    
                # Disegna la stella
                try:
                    stdscr.addch(screen_y, screen_x, star_char, curses.color_pair(color))
                except curses.error:
                    pass
                
                # Se è il sistema corrente, mostra un indicatore
                current_system = universe.get_current_system(player.position)
                if system == current_system:
                    try:
                        for i in range(1, 3):  # Piccolo cerchio attorno alla posizione
                            if screen_y-i >= 0:
                                stdscr.addch(screen_y-i, screen_x, '|', curses.color_pair(7))
                            if screen_y+i < self.height:
                                stdscr.addch(screen_y+i, screen_x, '|', curses.color_pair(7))
                            if screen_x-i >= 0:
                                stdscr.addch(screen_y, screen_x-i, '-', curses.color_pair(7))
                            if screen_x+i < self.width:
                                stdscr.addch(screen_y, screen_x+i, '-', curses.color_pair(7))
                    except curses.error:
                        pass
                
                # Se è il sistema selezionato, mostrare informazioni
                if game_state.selected_system == system:
                    # Evidenzia con un indicatore
                    for i in range(1, 4):
                        if screen_y-i >= 0 and screen_x-i >= 0:
                            stdscr.addch(screen_y-i, screen_x-i, '\\', curses.color_pair(3))
                        if screen_y-i >= 0 and screen_x+i < self.width:
                            stdscr.addch(screen_y-i, screen_x+i, '/', curses.color_pair(3))
                        if screen_y+i < self.height and screen_x-i >= 0:
                            stdscr.addch(screen_y+i, screen_x-i, '/', curses.color_pair(3))
                        if screen_y+i < self.height and screen_x+i < self.width:
                            stdscr.addch(screen_y+i, screen_x+i, '\\', curses.color_pair(3))
                    
                    # Mostra nome sistema
                    name = system.name[:20]  # Limita la lunghezza
                    name_pos_x = max(0, min(screen_x - len(name)//2, self.width - len(name)))
                    if screen_y + 2 < self.height:
                        stdscr.addstr(screen_y + 2, name_pos_x, name, curses.color_pair(7))
                        
                    # Mostra distanza
                    dist = player.position.distance(system.position)
                    dist_text = f"Dist: {dist:.1f} ly"
                    dist_pos_x = max(0, min(screen_x - len(dist_text)//2, self.width - len(dist_text)))
                    if screen_y + 3 < self.height:
                        stdscr.addstr(screen_y + 3, dist_pos_x, dist_text, curses.color_pair(6))
                        
                    # Mostra info pianeti
                    planet_text = f"Pianeti: {len(system.planets)}"
                    planet_pos_x = max(0, min(screen_x - len(planet_text)//2, self.width - len(planet_text)))
                    if screen_y + 4 < self.height:
                        stdscr.addstr(screen_y + 4, planet_pos_x, planet_text, curses.color_pair(6))
        
        # Disegna linea di rotta prevista dal giocatore al sistema selezionato
        if game_state.selected_system:
            try:
                dx = game_state.selected_system.position.x - player.position.x
                dz = game_state.selected_system.position.z - player.position.z
                
                end_x = center_x + int(dx * scale)
                end_y = center_y + int(dz * scale)
                
                # Disegna la linea tratteggiata
                self.draw_dashed_line(stdscr, player_x, player_y, end_x, end_y, '-', 2)
            except Exception as e:
                logger.error(f"Errore nel disegno della rotta: {e}")
    
    def draw_dashed_line(self, stdscr, x0, y0, x1, y1, char='-', color=2):
        """Disegna una linea tratteggiata tra due punti."""
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy
        
        dash_length = 2  # Lunghezza del trattino
        gap_length = 1   # Lunghezza dello spazio
        dash_counter = 0
        
        while True:
            if 0 <= x0 < self.width and 0 <= y0 < self.height:
                # Alterna trattini e spazi
                if dash_counter < dash_length:
                    try:
                        stdscr.addch(y0, x0, char, curses.color_pair(color))
                    except curses.error:
                        pass
                    
            dash_counter = (dash_counter + 1) % (dash_length + gap_length)
            
            if x0 == x1 and y0 == y1:
                break
                
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x0 += sx
            if e2 < dx:
                err += dx
                y0 += sy
    
    def render_station(self, stdscr, player, universe, game_state):
        """Renderizza l'interfaccia della stazione spaziale con maggiori dettagli."""
        logger.debug("Rendering vista stazione")
        
        # Calcola bordi e dimensioni della finestra principale
        padding = 2
        inner_width = self.width - padding * 2
        inner_height = self.height - padding * 2
        
        # Ottieni la stazione corrente
        current_system = universe.get_current_system(player.position)
        station = current_system.stations[0] if current_system and current_system.stations else None
        
        if not station:
            logger.warning("Tentativo di renderizzare una stazione inesistente")
            return
            
        # Disegna il bordo della stazione - usa z-buffer per evitare sfarfallio
        for y in range(padding, self.height-padding):
            for x in range(padding, self.width-padding):
                if (y == padding or y == self.height-padding-1 or 
                    x == padding or x == self.width-padding-1):
                    try:
                        stdscr.addch(y, x, '#', curses.color_pair(6))
                    except curses.error:
                        pass
        
        # Titolo e intestazione della stazione
        station_title = f"Stazione: {station.name}"
        title_x = (self.width - len(station_title)) // 2
        try:
            stdscr.addstr(padding + 1, title_x, station_title, curses.color_pair(3))
            # Linea decorativa sotto il titolo
            stdscr.addstr(padding + 2, padding + 2, "=" * (inner_width - 4), curses.color_pair(7))
        except curses.error:
            pass
            
        # Menu principale della stazione
        menu_items = [
            ("1", "Mercato", "Compra/vendi merci"),
            ("2", "Hangar", "Gestisci la tua nave"),
            ("3", "Missioni", "Cerca lavoro"),
            ("4", "Notizie", "Informazioni galattiche"),
            ("5", "Uscire", "Lascia la stazione")
        ]
        
        # Calcola posizione iniziale per il menu
        menu_start_y = padding + 4
        menu_col1_x = padding + 4
        menu_col2_x = padding + 14
        menu_col3_x = padding + 30
        
        # Disegna le opzioni del menu
        for i, (key, name, desc) in enumerate(menu_items):
            try:
                row_y = menu_start_y + i * 2
                if row_y < self.height - padding:
                    stdscr.addstr(row_y, menu_col1_x, key, curses.color_pair(3))
                    stdscr.addstr(row_y, menu_col2_x, name, curses.color_pair(6))
                    stdscr.addstr(row_y, menu_col3_x, desc, curses.color_pair(7))
            except curses.error:
                pass
        
        # Pannello informativo sulla destra
        info_panel_x = self.width // 2 + 5
        info_panel_y = padding + 4
        
        try:
            # Informazioni sulla stazione
            stdscr.addstr(info_panel_y, info_panel_x, "INFORMAZIONI STAZIONE", curses.color_pair(3))
            stdscr.addstr(info_panel_y + 2, info_panel_x, f"Sistema: {current_system.name}", curses.color_pair(7))
            stdscr.addstr(info_panel_y + 3, info_panel_x, f"Tipo: Orbitale commerciale", curses.color_pair(7))
            
            # Informazioni sul sistema
            stdscr.addstr(info_panel_y + 5, info_panel_x, "SISTEMA STELLARE", curses.color_pair(3))
            stdscr.addstr(info_panel_y + 7, info_panel_x, f"Stella: {current_system.star_type}", curses.color_pair(7))
            stdscr.addstr(info_panel_y + 8, info_panel_x, f"Pianeti: {len(current_system.planets)}", curses.color_pair(7))
            
            # Informazioni sulla nave
            stdscr.addstr(info_panel_y + 10, info_panel_x, "STATO NAVE", curses.color_pair(3))
            stdscr.addstr(info_panel_y + 12, info_panel_x, f"Crediti: {player.credits}", curses.color_pair(3))
            stdscr.addstr(info_panel_y + 13, info_panel_x, f"Carburante: {player.fuel:.1f}/{player.max_fuel}", curses.color_pair(7))
            stdscr.addstr(info_panel_y + 14, info_panel_x, f"Cargo: {sum(player.cargo.values())}/{player.cargo_capacity}", curses.color_pair(7))
        except curses.error:
            pass
    
    def render_hud(self, stdscr, player, game_state):
        """Renderizza l'HUD del gioco con informazioni complete."""
        # Pannello superiore sinistro - Informazioni di volo
        try:
            # Velocità
            speed_pct = int(player.speed / player.max_speed * 100)
            speed_str = f"VEL: {player.speed:.1f} m/s ({speed_pct}%)"
            stdscr.addstr(1, 2, speed_str, curses.color_pair(3))
            
            # Carburante con barra visiva
            fuel_pct = int(player.fuel / player.max_fuel * 10)
            fuel_bar = "[" + "#" * fuel_pct + " " * (10 - fuel_pct) + "]"
            fuel_str = f"FUEL: {player.fuel:.1f} {fuel_bar}"
            stdscr.addstr(2, 2, fuel_str, curses.color_pair(2 if fuel_pct > 3 else 1))
            
            # Coordinate
            pos_str = f"POS: {player.position.x:.1f}, {player.position.y:.1f}, {player.position.z:.1f}"
            stdscr.addstr(3, 2, pos_str, curses.color_pair(7))
            
            # Orientamento
            orient_str = f"HDG: P:{player.orientation.pitch:.0f} Y:{player.orientation.yaw:.0f} R:{player.orientation.roll:.0f}"
            stdscr.addstr(4, 2, orient_str, curses.color_pair(7))
        except curses.error:
            pass
            
        # Pannello superiore destro - Informazioni di sistema
        try:
            current_system = game_state.universe.get_current_system(player.position)
            status = f"Sistema: {current_system.name if current_system else 'Spazio profondo'}"
            stdscr.addstr(1, self.width - len(status) - 2, status, curses.color_pair(2 if current_system else 1))
            
            # Distanza alla stella centrale
            if current_system:
                dist_star = player.position.distance(current_system.position)
                dist_str = f"Dist. stella: {dist_star:.1f} unità"
                stdscr.addstr(2, self.width - len(dist_str) - 2, dist_str, curses.color_pair(7))
                
                # Pianeti nel sistema
                planet_str = f"Pianeti: {len(current_system.planets)}"
                stdscr.addstr(3, self.width - len(planet_str) - 2, planet_str, curses.color_pair(7))
                
                # Stazioni nel sistema
                station_str = f"Stazioni: {len(current_system.stations)}"
                stdscr.addstr(4, self.width - len(station_str) - 2, station_str, curses.color_pair(7))
        except curses.error:
            pass
            
        # Barre di stato al centro migliorate
        try:
            # Calcola larghezza disponibile
            center_width = min(60, self.width - 40)  # Limitato a 60 o spazio disponibile
            if center_width > 20:  # Solo se c'è abbastanza spazio
                center_x = 20
                    
                # Scudi - con carattere blocco pieno per barra più visibile
                shield_pct = int(player.shields / player.max_shields * center_width)
                shield_bar = "[" + self.PIXEL_CHARS['full'] * shield_pct + " " * (center_width - shield_pct) + "]"
                stdscr.addstr(1, center_x, f"SCUDI: {shield_bar}", curses.color_pair(4))
                    
                # Scafo - con carattere blocco pieno per barra più visibile
                hull_pct = int(player.hull / player.max_hull * center_width)
                hull_bar = "[" + self.PIXEL_CHARS['full'] * hull_pct + " " * (center_width - hull_pct) + "]"
                hull_color = 2 if hull_pct > center_width * 0.5 else (3 if hull_pct > center_width * 0.25 else 1)
                stdscr.addstr(2, center_x, f"SCAFO: {hull_bar}", curses.color_pair(hull_color))
        except curses.error:
            pass
    
    def render_radar(self, stdscr, player, universe, game_state):
        """Renderizza un radar circolare che mostra oggetti vicini."""
        # Centro del radar
        radar_size = 8  # Raggio in caratteri
        center_y = self.height - radar_size - 3
        center_x = self.width - radar_size - 3
        
        # Disegna il bordo del radar
        radar_border = []
        for angle in range(0, 360, 15):  # Bordo circolare approssimato
            rad = math.radians(angle)
            x = int(center_x + radar_size * math.cos(rad))
            y = int(center_y + radar_size * math.sin(rad) / 2)  # Dividi per 2 per compensare i caratteri rettangolari
            
            if 0 <= x < self.width and 0 <= y < self.height:
                radar_border.append((y, x, '.', curses.color_pair(7)))
        
        # Disegna il bordo
        for y, x, char, attr in radar_border:
            try:
                stdscr.addch(y, x, char, attr)
            except curses.error:
                pass
        
        # Disegna le coordinate sul radar
        try:
            # Disegna gli assi principali
            stdscr.addch(center_y, center_x + radar_size, 'E', curses.color_pair(3))  # Est
            stdscr.addch(center_y, center_x - radar_size, 'W', curses.color_pair(3))  # Ovest
            stdscr.addch(center_y - radar_size//2, center_x, 'N', curses.color_pair(3))  # Nord
            stdscr.addch(center_y + radar_size//2, center_x, 'S', curses.color_pair(3))  # Sud
        except curses.error:
            pass
        
        # Disegna il giocatore al centro
        try:
            stdscr.addch(center_y, center_x, '+', curses.color_pair(3))
        except curses.error:
            pass
        
        # Ottieni oggetti nelle vicinanze
        current_system = universe.get_current_system(player.position)
        if current_system:
            # Calcola l'orientamento giocatore in radianti per il radar
            yaw_rad = math.radians(player.orientation.yaw)
            
            # Mostra pianeti sul radar
            for planet in current_system.planets:
                # Calcola vettore relativo dal giocatore al pianeta
                rel_vector = planet.position.subtract(player.position)
                distance = rel_vector.length()
                
                if distance <= radar_size * 5:  # Scala del radar
                    # Calcola posizione radar, considerando la rotazione del giocatore
                    # X e Z sono le coordinate orizzontali nel gioco
                    dx = rel_vector.x
                    dz = rel_vector.z
                    
                    # Ruota in base all'orientamento del giocatore
                    radar_x = dx * math.cos(yaw_rad) + dz * math.sin(yaw_rad)
                    radar_z = -dx * math.sin(yaw_rad) + dz * math.cos(yaw_rad)
                    
                    # Scala e posiziona sul radar
                    scaled_x = int(center_x + radar_x / 5)
                    scaled_y = int(center_y + radar_z / 10)  # Compensazione per caratteri rettangolari
                    
                    if 0 <= scaled_x < self.width and 0 <= scaled_y < self.height:
                        try:
                            # Usiamo 'P' per pianeti per renderli più visibili
                            stdscr.addch(scaled_y, scaled_x, 'P', curses.color_pair(planet.get_color()))
                            
                            # Mostra coordinate per il pianeta più vicino
                            if distance < radar_size * 2:  # Solo se abbastanza vicino
                                coord_str = f"{planet.name}: {rel_vector.x:.1f},{rel_vector.y:.1f},{rel_vector.z:.1f}"
                                # Mostra coordinate sotto il radar
                                coord_y = center_y + radar_size + 1
                                if coord_y < self.height - 1:
                                    self._safe_addstr(stdscr, coord_y, center_x - len(coord_str)//2, 
                                                     coord_str, curses.color_pair(7))
                        except curses.error:
                            pass
                            
            # Mostra stazioni sul radar
            for station in current_system.stations:
                rel_vector = station.position.subtract(player.position)
                distance = rel_vector.length()
                
                if distance <= radar_size * 5:
                    # Stessa logica di rotazione e posizionamento dei pianeti
                    dx = rel_vector.x
                    dz = rel_vector.z
                    
                    radar_x = dx * math.cos(yaw_rad) + dz * math.sin(yaw_rad)
                    radar_z = -dx * math.sin(yaw_rad) + dz * math.cos(yaw_rad)
                    
                    scaled_x = int(center_x + radar_x / 5)
                    scaled_y = int(center_y + radar_z / 10)
                    
                    if 0 <= scaled_x < self.width and 0 <= scaled_y < self.height:
                        try:
                            # Usiamo 'S' per stazioni
                            stdscr.addch(scaled_y, scaled_x, 'S', curses.color_pair(6))
                        except curses.error:
                            pass
    
    def _safe_addstr(self, stdscr, y, x, text, attr=0):
        """Sicuro addstr con gestione errori out-of-bounds."""
        try:
            stdscr.addstr(y, x, text, attr)
        except curses.error:
            pass
    
    def clear_caches(self):
        """Pulisce le cache per liberare memoria."""
        memory_manager.clear_cache("proj_")
        memory_manager.clear_cache("scene_")
        self.projection_cache.clear()
        self.transform_cache.clear()
    
    def on_config_changed(self, event_type, data):
        """Gestisce le modifiche alle configurazioni."""
        if not data:
            return
            
        key = data.get('key', '')
        
        # Se è un reset completo, ricarica tutte le configurazioni
        if key == 'all':
            config = get_config()
            self.fov = config.get("graphics.fov", 60)
            self.render_wireframe = config.get("graphics.render_wireframe", True)
            self.use_z_buffer = config.get("graphics.use_z_buffer", True)
            self.frustum_culling = config.get("graphics.frustum_culling", True)
            self.render_distance = config.get("graphics.render_distance", 500.0)
            return
            
        # Aggiorna singole configurazioni
        if 'graphics.fov' in key:
            self.fov = data.get('value', 60)
        elif 'graphics.render_wireframe' in key:
            self.render_wireframe = data.get('value', True)
        elif 'graphics.use_z_buffer' in key:
            self.use_z_buffer = data.get('value', True)
        elif 'graphics.frustum_culling' in key:
            self.frustum_culling = data.get('value', True)
    
    def _render_top_status_bar(self, stdscr):
        """Renderizza la barra di stato superiore."""
        try:
            # Crea una barra bianca
            for x in range(self.width):
                stdscr.addch(0, x, ' ', curses.color_pair(7) | curses.A_REVERSE)
                
            # Aggiungi il testo
            title = "Terminale Matrix 1.0.1 per supporto di volo"
            x = (self.width - len(title)) // 2
            stdscr.addstr(0, x, title, curses.color_pair(7) | curses.A_REVERSE | curses.A_BOLD)
        except curses.error:
            pass
