"""
Sistema di monitoraggio prestazioni per Frontier Elite 2 ASCII Edition
"""
import time
import statistics
import threading
import os
import psutil
from typing import Dict, List, Tuple, Optional
from .logger import get_logger
from .event_system import get_event_system, GameEventType

logger = get_logger()
event_system = get_event_system()

class PerformanceMonitor:
    """Monitora vari aspetti delle prestazioni del gioco."""
    
    def __init__(self, enabled=True, sampling_interval=1.0):
        """
        Inizializza il monitor di prestazioni.
        
        Args:
            enabled: Se il monitor è attivo
            sampling_interval: Intervallo di campionamento in secondi
        """
        self.enabled = enabled
        self.sampling_interval = sampling_interval
        self.metrics: Dict[str, List[float]] = {
            "fps": [],
            "frame_time": [],
            "memory_usage": [],
            "cpu_usage": [],
            "render_time": [],
            "update_time": [],
            "ui_time": []
        }
        self.max_samples = 100  # Limita la memoria usata
        self.start_time = time.time()
        self.last_sample_time = time.time()
        self.total_frames = 0
        self.frames_since_last_sample = 0
        self.active_timers: Dict[str, float] = {}
        
        # Sistema di profiling avanzato
        self.profile_data: Dict[str, Dict[str, float]] = {}
        
        # Registra i listener per gli eventi di gameplay
        event_system.subscribe(GameEventType.NOTIFICATION, self._on_notification)
        
        # Inizia il monitoraggio in thread separato se richiesto
        self.monitoring_thread = None
        if enabled:
            self._start_monitoring_thread()
        
        logger.info("Performance Monitor inizializzato")
    
    def _start_monitoring_thread(self):
        """Avvia un thread separato per monitorare le prestazioni del sistema."""
        if self.monitoring_thread is not None:
            return
            
        def monitor_loop():
            while self.enabled:
                self._sample_system_metrics()
                time.sleep(self.sampling_interval)
                
        self.monitoring_thread = threading.Thread(
            target=monitor_loop, 
            name="PerfMonThread", 
            daemon=True
        )
        self.monitoring_thread.start()
    
    def _sample_system_metrics(self):
        """Campiona metriche di sistema."""
        try:
            # Misura l'uso della memoria
            process = psutil.Process(os.getpid())
            memory_mb = process.memory_info().rss / (1024 * 1024)
            self.metrics["memory_usage"].append(memory_mb)
            
            # Misura l'uso della CPU
            cpu_percent = process.cpu_percent(interval=None)
            self.metrics["cpu_usage"].append(cpu_percent)
            
            # Limita la dimensione degli array
            for key in self.metrics:
                if len(self.metrics[key]) > self.max_samples:
                    self.metrics[key] = self.metrics[key][-self.max_samples:]
                    
        except Exception as e:
            logger.warning(f"Errore nel campionamento delle metriche di sistema: {str(e)}")
    
    def _on_notification(self, event_type, data):
        """Gestisce notifiche di prestazioni dall'engine."""
        if not data or 'type' not in data:
            return
            
        # Raccolta dei tempi di rendering
        if data['type'] == 'render_complete':
            stats = data.get('stats', {})
            if 'render_time_ms' in stats:
                self.metrics["render_time"].append(stats["render_time_ms"])
                if len(self.metrics["render_time"]) > self.max_samples:
                    self.metrics["render_time"] = self.metrics["render_time"][-self.max_samples:]
    
    def frame_rendered(self, frame_time: float):
        """Notifica che un frame è stato completato."""
        if not self.enabled:
            return
            
        self.total_frames += 1
        self.frames_since_last_sample += 1
        self.metrics["frame_time"].append(frame_time * 1000)  # Converti in ms
        
        current_time = time.time()
        elapsed = current_time - self.last_sample_time
        
        if elapsed >= self.sampling_interval:
            # Calcola FPS
            fps = self.frames_since_last_sample / elapsed
            self.metrics["fps"].append(fps)
            
            # Reset contatori
            self.last_sample_time = current_time
            self.frames_since_last_sample = 0
            
            # Limita la dimensione degli array
            if len(self.metrics["fps"]) > self.max_samples:
                self.metrics["fps"] = self.metrics["fps"][-self.max_samples:]
            if len(self.metrics["frame_time"]) > self.max_samples:
                self.metrics["frame_time"] = self.metrics["frame_time"][-self.max_samples:]
    
    def start_timer(self, name: str):
        """Inizia a misurare il tempo per un'operazione."""
        if not self.enabled:
            return
        self.active_timers[name] = time.time()
    
    def end_timer(self, name: str):
        """Termina la misurazione del tempo per un'operazione."""
        if not self.enabled or name not in self.active_timers:
            return
            
        elapsed = (time.time() - self.active_timers[name]) * 1000  # ms
        if name not in self.metrics:
            self.metrics[name] = []
            
        self.metrics[name].append(elapsed)
        if len(self.metrics[name]) > self.max_samples:
            self.metrics[name] = self.metrics[name][-self.max_samples:]
            
        del self.active_timers[name]
    
    def get_average(self, metric: str) -> Optional[float]:
        """Ottiene il valore medio di una metrica."""
        values = self.metrics.get(metric, [])
        if not values:
            return None
        return statistics.mean(values)
    
    def get_stats(self) -> Dict[str, Dict[str, float]]:
        """Ottiene statistiche complete per tutte le metriche."""
        stats = {}
        for metric, values in self.metrics.items():
            if values:
                stats[metric] = {
                    "min": min(values),
                    "max": max(values),
                    "avg": statistics.mean(values),
                    "current": values[-1]
                }
                
                # Calcola deviazione standard se ci sono abbastanza dati
                if len(values) > 1:
                    stats[metric]["stddev"] = statistics.stdev(values)
                    
        return stats
    
    def log_stats(self):
        """Registra le statistiche principali nel log."""
        if not self.enabled:
            return
            
        stats = {}
        for key in ["fps", "frame_time", "memory_usage", "cpu_usage"]:
            avg = self.get_average(key)
            if avg is not None:
                stats[key] = avg
                
        stats_str = ", ".join(f"{k}: {v:.2f}" for k, v in stats.items())
        logger.info(f"Statistiche prestazioni: {stats_str}")
    
    def profile(self, name: str):
        """Decoratore per profilare funzioni."""
        def decorator(func):
            def wrapper(*args, **kwargs):
                if not self.enabled:
                    return func(*args, **kwargs)
                    
                start = time.time()
                result = func(*args, **kwargs)
                elapsed = (time.time() - start) * 1000  # ms
                
                # Aggiorna le statistiche di profiling
                if name not in self.profile_data:
                    self.profile_data[name] = {"calls": 0, "total_time": 0, "min": float('inf'), "max": 0}
                    
                self.profile_data[name]["calls"] += 1
                self.profile_data[name]["total_time"] += elapsed
                self.profile_data[name]["min"] = min(self.profile_data[name]["min"], elapsed)
                self.profile_data[name]["max"] = max(self.profile_data[name]["max"], elapsed)
                
                return result
            return wrapper
        return decorator

# Istanza globale del monitor di prestazioni
_performance_monitor = None

def get_performance_monitor() -> PerformanceMonitor:
    """Restituisce l'istanza globale del monitor di prestazioni."""
    global _performance_monitor
    if _performance_monitor is None:
        _performance_monitor = PerformanceMonitor()
    return _performance_monitor
