"""
Gestisce lo stato di gioco e la logica di controllo
"""
import curses
import time
from .logger import get_logger
from .memory_manager import get_memory_manager
from .event_system import get_event_system, GameEventType

logger = get_logger()
memory_manager = get_memory_manager()
event_system = get_event_system()

class GameState:
    def __init__(self, universe, player):
        self.universe = universe
        self.player = player
        self.current_view = "space"  # "space", "starmap", "station"
        self.starmap_scale = 0.1
        self.selected_system = None
        self.messages = []
        self.target = None
        self.last_key_time = {}
        self.key_repeat_delay = 0.1  # secondi
        
        # Usa il memory manager per effettuare la pulizia periodica
        self.last_memory_cleanup = time.time()
        self.cleanup_interval = 60  # Secondi
        
        logger.info("Stato di gioco inizializzato")
        
        # Pubblica evento di inizio gioco
        event_system.publish(GameEventType.GAME_START, self)
    
    def update(self, key, delta_time):
        """Aggiorna lo stato di gioco in base all'input utente."""
        current_time = time.time()
        
        # Funzione per verificare se un tasto può essere ripetuto
        def can_repeat(k):
            if k not in self.last_key_time:
                self.last_key_time[k] = current_time
                return True
            if current_time - self.last_key_time[k] >= self.key_repeat_delay:
                self.last_key_time[k] = current_time
                return True
            return False
        
        # Gestione input per la vista spaziale
        if self.current_view == "space":
            # Rotazione
            if key == ord('a') and can_repeat(ord('a')):
                self.player.rotate(0, -5, 0)  # Gira a sinistra
            elif key == ord('d') and can_repeat(ord('d')):
                self.player.rotate(0, 5, 0)   # Gira a destra
            elif key == ord('w') and can_repeat(ord('w')):
                self.player.rotate(-5, 0, 0)  # Su
            elif key == ord('s') and can_repeat(ord('s')):
                self.player.rotate(5, 0, 0)   # Giù
            elif key == ord('q') and can_repeat(ord('q')):
                self.player.rotate(0, 0, -5)  # Rollio sinistra
            elif key == ord('e') and can_repeat(ord('e')):
                self.player.rotate(0, 0, 5)   # Rollio destra
            
            # Velocità
            elif key == ord('r') and can_repeat(ord('r')):
                self.player.accelerate(0.5)   # Accelera
            elif key == ord('f') and can_repeat(ord('f')):
                self.player.accelerate(-0.5)  # Decelera
            
            # Cambio vista
            elif key == ord('m'):
                old_view = self.current_view
                self.current_view = "starmap"
                self.selected_system = self.universe.get_current_system(self.player.position)
                logger.debug("Cambio vista: da spazio a mappa stellare")
                
                # Pubblica evento di cambio vista
                event_system.publish(GameEventType.VIEW_CHANGE, {
                    'old_view': old_view, 
                    'new_view': self.current_view
                })
            
            # Dock con stazione (se vicino)
            elif key == ord('b'):
                current_system = self.universe.get_current_system(self.player.position)
                if current_system and current_system.stations:
                    nearest_station = current_system.stations[0]
                    if self.player.position.distance(nearest_station.position) < 5:
                        old_view = self.current_view
                        self.current_view = "station"
                        
                        # Pubblica evento di attracco
                        event_system.publish(GameEventType.PLAYER_DOCK, {
                            'player': self.player,
                            'station': nearest_station
                        })
                        
                        # Pubblica evento di cambio vista
                        event_system.publish(GameEventType.VIEW_CHANGE, {
                            'old_view': old_view, 
                            'new_view': self.current_view
                        })
                    else:
                        self.add_message("Troppo lontano dalla stazione per attraccare", 1)
                else:
                    self.add_message("Nessuna stazione in questo sistema", 1)
        
        # Gestione input per la mappa stellare
        elif self.current_view == "starmap":
            if key == ord('m') or key == 27:  # 'm' o ESC
                old_view = self.current_view
                self.current_view = "space"
                logger.debug("Cambio vista: da mappa stellare a spazio")
                
                # Pubblica evento di cambio vista
                event_system.publish(GameEventType.VIEW_CHANGE, {
                    'old_view': old_view, 
                    'new_view': self.current_view
                })
            
            # Navigazione nella mappa
            elif key == curses.KEY_UP and can_repeat(curses.KEY_UP):
                # Spostare la selezione verso l'alto
                self.select_nearest_system(0, -1)
            elif key == curses.KEY_DOWN and can_repeat(curses.KEY_DOWN):
                # Spostare la selezione verso il basso
                self.select_nearest_system(0, 1)
            elif key == curses.KEY_LEFT and can_repeat(curses.KEY_LEFT):
                # Spostare la selezione a sinistra
                self.select_nearest_system(-1, 0)
            elif key == curses.KEY_RIGHT and can_repeat(curses.KEY_RIGHT):
                # Spostare la selezione a destra
                self.select_nearest_system(1, 0)
            
            # Salto iperspaziale al sistema selezionato
            elif key == ord('j') and self.selected_system:
                if self.player.jump_to_system(self.selected_system):
                    self.add_message(f"Salto completato a {self.selected_system.name}", 3)
                    old_view = self.current_view
                    self.current_view = "space"
                    
                    # Pubblica evento di salto del giocatore
                    event_system.publish(GameEventType.PLAYER_JUMP, {
                        'player': self.player,
                        'target_system': self.selected_system
                    })
                    
                    # Pubblica evento di cambio vista
                    event_system.publish(GameEventType.VIEW_CHANGE, {
                        'old_view': old_view, 
                        'new_view': self.current_view
                    })
                else:
                    self.add_message("Carburante insufficiente per il salto", 1)
            
            # Zoom della mappa
            elif key == ord('+') and can_repeat(ord('+')):
                self.starmap_scale *= 1.2
            elif key == ord('-') and can_repeat(ord('-')):
                self.starmap_scale /= 1.2
        
        # Gestione input per la stazione
        elif self.current_view == "station":
            if key == 27:  # ESC
                self.current_view = "space"
            elif key == ord('1'):
                # Mercato
                pass
            elif key == ord('2'):
                # Hangar
                pass
            elif key == ord('3'):
                # Missioni
                pass
            elif key == ord('4'):
                # Notizie
                pass
            elif key == ord('5'):
                # Esci dalla stazione
                self.current_view = "space"
        
        # Aggiorna la nave del giocatore
        self.player.update(delta_time)
        
        # Pulizia memoria periodica
        if current_time - self.last_memory_cleanup > self.cleanup_interval:
            memory_manager.force_collection()
            self.last_memory_cleanup = current_time
        
        # Pubblica cambio vista quando necessario
        old_view = self.current_view
        if self.current_view != old_view:
            event_system.publish(GameEventType.VIEW_CHANGE, {
                'old_view': old_view, 
                'new_view': self.current_view
            })
    
    def select_nearest_system(self, dx, dy):
        """Seleziona il sistema stellare più vicino nella direzione indicata."""
        if not self.selected_system:
            self.selected_system = self.universe.get_current_system(self.player.position)
            return
            
        current_pos = self.selected_system.position
        min_distance = float('inf')
        nearest_system = None
        
        # Direzione di ricerca
        direction = (dx, dy)
        
        for system in self.universe.systems:
            # Calcola il vettore dalla posizione attuale al sistema
            system_dx = system.position.x - current_pos.x
            system_dz = system.position.z - current_pos.z  # Usiamo z come seconda coordinata 2D
            
            # Verifica se il sistema è nella direzione richiesta
            correct_direction = False
            if dx > 0 and system_dx > 0 or dx < 0 and system_dx < 0 or dx == 0:
                if dy > 0 and system_dz > 0 or dy < 0 and system_dz < 0 or dy == 0:
                    if dx != 0 or dy != 0:  # Assicurati che almeno una direzione sia non-zero
                        correct_direction = True
            
            if correct_direction and system != self.selected_system:
                # Calcola la distanza al sistema
                distance = ((system_dx ** 2) + (system_dz ** 2)) ** 0.5
                if distance < min_distance:
                    min_distance = distance
                    nearest_system = system
        
        if nearest_system:
            self.selected_system = nearest_system
    
    def add_message(self, text, color=7):
        """Aggiunge un messaggio alla coda dei messaggi."""
        logger.debug(f"Messaggio UI: {text}")
        self.messages.append((text, color, time.time()))
        # Mantieni solo gli ultimi 5 messaggi
        if len(self.messages) > 5:
            self.messages.pop(0)
