"""
Sistema di fisica per Frontier Elite 2 ASCII Edition
Implementa collisioni, gravitazione e movimento realistico
"""
import math
import time
from typing import List, Tuple, Dict, Any
from .vector import Vector3D
from .logger import get_logger
from .event_system import get_event_system, GameEventType
from .config import get_config

logger = get_logger()
event_system = get_event_system()
config = get_config()

class PhysicsEngine:
    """Motore fisico che gestisce collisioni e forze."""
    
    def __init__(self):
        """Inizializza il motore fisico."""
        # Costanti fisiche
        self.G = 6.67430e-11  # Costante gravitazionale (m^3 kg^-1 s^-2)
        self.scale_factor = 1e9  # Scala per adattare distanze astronomiche
        
        # Orologio di gioco globale
        self.global_time = time.time()
        self.time_scale = config.get("physics.time_scale", 1.0)  # Scala del tempo
        
        # Oggetti con fisica
        self.physical_objects = {}  # id -> object
        
        # Impostazioni di collisione
        self.collision_enabled = True
        self.collision_damage_factor = config.get("physics.collision_damage_factor", 0.5)
        self.collision_rebound_factor = config.get("physics.collision_rebound_factor", 1.0)
        
        # Statistiche e debug
        self.collision_count = 0
        self.last_collision_time = 0
        
        logger.info("Sistema fisico inizializzato")
    
    def register_object(self, obj_id, obj):
        """Registra un oggetto per la simulazione fisica."""
        self.physical_objects[obj_id] = obj
        
    def unregister_object(self, obj_id):
        """Rimuove un oggetto dalla simulazione fisica."""
        if obj_id in self.physical_objects:
            del self.physical_objects[obj_id]
    
    def update(self, delta_time):
        """Aggiorna la simulazione fisica."""
        # Aggiorna l'orologio globale
        self.global_time += delta_time * self.time_scale
        
        # Processa le collisioni
        if self.collision_enabled:
            self.check_collisions()
        
        # Applica la gravitazione ai corpi
        self.apply_gravity(delta_time)
        
    def check_collisions(self):
        """Verifica collisioni tra tutti gli oggetti fisici."""
        objects = list(self.physical_objects.items())
        
        # Confronta ogni coppia di oggetti
        for i in range(len(objects)):
            id1, obj1 = objects[i]
            
            for j in range(i+1, len(objects)):
                id2, obj2 = objects[j]
                
                # Calcola distanza tra gli oggetti
                if hasattr(obj1, 'position') and hasattr(obj2, 'position'):
                    distance = obj1.position.distance(obj2.position)
                    combined_radius = getattr(obj1, 'radius', 0) + getattr(obj2, 'radius', 0)
                    
                    # Se la distanza è minore della somma dei raggi, abbiamo una collisione
                    if distance < combined_radius:
                        self.handle_collision(obj1, obj2)
    
    def handle_collision(self, obj1, obj2):
        """Gestisce una collisione tra due oggetti."""
        self.collision_count += 1
        self.last_collision_time = time.time()
        
        # Calcola il vettore di collisione (dalla posizione di obj1 a obj2)
        collision_vector = obj2.position.subtract(obj1.position).normalize()
        
        # Determina la massa relativa per il rimbalzo (pianeti hanno massa infinita)
        mass1 = getattr(obj1, 'mass', 1.0)
        mass2 = getattr(obj2, 'mass', 1.0)
        
        # Pianeti e stelle sono "immobili" (massa infinita)
        if hasattr(obj1, 'type') and obj1.type in ['planet', 'star']:
            mass1 = float('inf')
        if hasattr(obj2, 'type') and obj2.type in ['planet', 'star']:
            mass2 = float('inf')
            
        # Calcola velocità relative
        vel1 = Vector3D()
        vel2 = Vector3D()
        
        if hasattr(obj1, 'velocity'):
            vel1 = obj1.velocity
        elif hasattr(obj1, 'speed') and hasattr(obj1, 'orientation'):
            forward = obj1.orientation.get_forward_vector()
            vel1 = forward.scale(obj1.speed)
            
        if hasattr(obj2, 'velocity'):
            vel2 = obj2.velocity
        elif hasattr(obj2, 'speed') and hasattr(obj2, 'orientation'):
            forward = obj2.orientation.get_forward_vector()
            vel2 = forward.scale(obj2.speed)
        
        # Calcola l'impulso della collisione (versione semplificata)
        relative_vel = vel1.subtract(vel2)
        vel_along_normal = relative_vel.dot(collision_vector)
        
        # Se gli oggetti si stanno allontanando, ignora la collisione
        if vel_along_normal > 0:
            return
            
        # Calcola l'impulso scalare
        restitution = self.collision_rebound_factor  # Elasticità della collisione
        impulse_scalar = -(1 + restitution) * vel_along_normal
        
        # Calcola le nuove velocità
        if mass1 != float('inf') and hasattr(obj1, 'speed'):
            # Calcola nuova velocità per obj1
            impulse = collision_vector.scale(-impulse_scalar / mass1)
            new_speed = max(0, obj1.speed - impulse.length())
            obj1.speed = new_speed
            
            # Aggiorna posizione per evitare sovrapposizioni
            overlap = (getattr(obj1, 'radius', 0) + getattr(obj2, 'radius', 0) - obj1.position.distance(obj2.position)) / 2
            correction = collision_vector.scale(-overlap)
            if hasattr(obj1, 'position'):
                obj1.position = obj1.position.add(correction)
        
        if mass2 != float('inf') and hasattr(obj2, 'speed'):
            # Calcola nuova velocità per obj2
            impulse = collision_vector.scale(impulse_scalar / mass2)
            new_speed = max(0, obj2.speed - impulse.length())
            obj2.speed = new_speed
            
            # Aggiorna posizione per evitare sovrapposizioni
            overlap = (getattr(obj1, 'radius', 0) + getattr(obj2, 'radius', 0) - obj1.position.distance(obj2.position)) / 2
            correction = collision_vector.scale(overlap)
            if hasattr(obj2, 'position'):
                obj2.position = obj2.position.add(correction)
        
        # Calcola e applica i danni (se gli oggetti supportano hull/shields)
        damage_energy = relative_vel.length_squared() * self.collision_damage_factor
        
        if hasattr(obj1, 'take_damage'):
            damage1 = damage_energy / mass1 if mass1 != float('inf') else 0
            obj1.take_damage(damage1, "collision")
            
        if hasattr(obj2, 'take_damage'):
            damage2 = damage_energy / mass2 if mass2 != float('inf') else 0
            obj2.take_damage(damage2, "collision")
        
        # Pubblica evento di collisione
        event_system.publish(GameEventType.COLLISION, {
            'obj1': obj1,
            'obj2': obj2,
            'impact_speed': relative_vel.length(),
            'damage_energy': damage_energy
        })
            
    def apply_gravity(self, delta_time):
        """Applica forze gravitazionali a tutti gli oggetti."""
        for obj_id, obj in self.physical_objects.items():
            # Salta oggetti senza posizione o non soggetti a gravità
            if not hasattr(obj, 'position') or getattr(obj, 'ignore_gravity', False):
                continue
                
            # Trova il pianeta/stella più vicino per gravità
            closest_body = None
            closest_distance = float('inf')
            
            for other_id, other in self.physical_objects.items():
                if obj_id == other_id:
                    continue
                    
                # Solo pianeti e stelle esercitano gravità
                if not hasattr(other, 'type') or other.type not in ['planet', 'star']:
                    continue
                    
                distance = obj.position.distance(other.position)
                if distance < closest_distance:
                    closest_distance = distance
                    closest_body = other
            
            # Se abbiamo trovato un corpo vicino, applicagli gravità
            if closest_body and hasattr(obj, 'speed') and hasattr(obj, 'orientation'):
                # Ignora gravità se troppo lontano
                if closest_distance > 50 * getattr(closest_body, 'radius', 1):
                    continue
                    
                # Calcola forza gravitazionale
                body_mass = getattr(closest_body, 'mass', 1e24)  # Massa predefinita
                gravity_strength = self.G * body_mass / (closest_distance * closest_distance)
                gravity_strength /= self.scale_factor  # Scala per rendere l'effetto visibile
                
                # Vettore direzionale verso il corpo
                direction = closest_body.position.subtract(obj.position).normalize()
                
                # Applica l'effetto alla velocità
                if hasattr(obj, 'velocity'):
                    # Oggetto con fisica completa
                    gravity_force = direction.scale(gravity_strength * delta_time)
                    obj.velocity = obj.velocity.add(gravity_force)
                else:
                    # Oggetto semplice (solo velocità scalare)
                    # Modifichiamo leggermente l'orientamento verso il corpo
                    current_forward = obj.orientation.get_forward_vector()
                    angle_factor = 0.01 * gravity_strength  # Fattore di rotazione gravitazionale
                    
                    # Calcola componenti di rotazione necessarie
                    dot_product = current_forward.dot(direction)
                    cross_product = current_forward.cross(direction)
                    
                    # Applica una leggera rotazione verso il corpo gravitazionale
                    if dot_product < 0.99:  # Non ruotare se già allineato
                        pitch_adjustment = cross_product.x * angle_factor
                        yaw_adjustment = cross_product.y * angle_factor
                        obj.orientation.rotate(pitch_adjustment, yaw_adjustment, 0)

# Istanza globale del motore fisico
_physics_engine = None

def get_physics_engine():
    """Restituisce l'istanza globale del motore fisico."""
    global _physics_engine
    if _physics_engine is None:
        _physics_engine = PhysicsEngine()
    return _physics_engine
