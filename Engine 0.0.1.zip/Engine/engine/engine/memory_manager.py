"""
Gestore di memoria efficiente per Frontier Elite 2 ASCII Edition
Implementa tecniche per minimizzare l'uso di memoria su dispositivi limitati
"""
import gc
import weakref
import sys
import os
import time  # Aggiungiamo l'importazione mancante
import psutil
from typing import Dict, List, TypeVar, Generic, Type, Optional, Any, Tuple
from .logger import get_logger

logger = get_logger()

T = TypeVar('T')

class ObjectPool(Generic[T]):
    """
    Pool di oggetti per riutilizzare istanze invece di crearne di nuove,
    riducendo l'allocazione di memoria e il lavoro del garbage collector.
    """
    
    def __init__(self, object_type: Type[T], initial_capacity: int = 10, 
                 max_size: int = 100, default_args: Tuple = None, default_kwargs: Dict = None):
        """
        Inizializza un pool di oggetti.
        
        Args:
            object_type: La classe degli oggetti da gestire nel pool
            initial_capacity: Numero iniziale di oggetti da pre-allocare
            max_size: Dimensione massima del pool
            default_args: Argomenti posizionali predefiniti per la creazione di oggetti
            default_kwargs: Argomenti keyword predefiniti per la creazione di oggetti
        """
        self.object_type = object_type
        self.max_size = max_size
        self.default_args = default_args or ()
        self.default_kwargs = default_kwargs or {}
        self.pool: List[T] = []
        self.active_objects: Dict[int, weakref.ref] = {}
        
        # Pre-alloca gli oggetti
        for _ in range(initial_capacity):
            self.pool.append(self._create_object())
        
        logger.debug(f"Pool creato per {object_type.__name__}, capacità iniziale: {initial_capacity}")
    
    def _create_object(self) -> T:
        """Crea una nuova istanza dell'oggetto usando i parametri predefiniti."""
        return self.object_type(*self.default_args, **self.default_kwargs)
    
    def acquire(self, *args, **kwargs) -> T:
        """
        Ottiene un oggetto dal pool o ne crea uno nuovo se necessario.
        
        Returns:
            Un'istanza dell'oggetto richiesto
        """
        if self.pool:
            # Riutilizza un oggetto esistente
            obj = self.pool.pop()
        else:
            # Crea un nuovo oggetto se il pool è vuoto
            obj = self._create_object()
        
        # Inizializza l'oggetto se ha un metodo reset
        if hasattr(obj, 'reset') and callable(getattr(obj, 'reset')):
            obj.reset(*args, **kwargs)
            
        # Tieni traccia dell'oggetto attivo con weakref
        self.active_objects[id(obj)] = weakref.ref(obj)
        
        return obj
    
    def release(self, obj: T) -> bool:
        """
        Restituisce un oggetto al pool per riutilizzo.
        
        Args:
            obj: L'oggetto da restituire al pool
            
        Returns:
            True se l'oggetto è stato aggiunto al pool, False altrimenti
        """
        obj_id = id(obj)
        if obj_id in self.active_objects:
            del self.active_objects[obj_id]
            
            # Aggiungi al pool solo se non è pieno
            if len(self.pool) < self.max_size:
                self.pool.append(obj)
                return True
        return False
    
    def clear(self):
        """Svuota il pool e rilascia tutti i riferimenti."""
        self.pool.clear()
        self.active_objects.clear()
        
    def collect_garbage(self):
        """Raccoglie oggetti non più utilizzati dal pool."""
        # Controlla quali oggetti attivi sono stati raccolti dal GC
        dead_refs = []
        for obj_id, weak_ref in self.active_objects.items():
            if weak_ref() is None:
                dead_refs.append(obj_id)
        
        # Rimuovi i riferimenti morti
        for obj_id in dead_refs:
            del self.active_objects[obj_id]
        
        return len(dead_refs)

class MemoryManager:
    """
    Gestisce l'allocazione e il rilascio efficiente di memoria.
    Implementa tecniche come object pooling, lazy loading e garbage collection esplicita.
    """
    
    def __init__(self):
        """Inizializza il memory manager."""
        self.pools: Dict[Type, ObjectPool] = {}
        self.cached_data: Dict[str, Any] = {}
        self.memory_stats = {
            'peak': 0, 
            'last_check': 0,
            'collections': 0,
            'cache_hits': 0,
            'cache_misses': 0
        }
        self.has_psutil = 'psutil' in sys.modules
        logger.info("Memory Manager inizializzato")
    
    def get_pool(self, object_type: Type[T], initial_capacity: int = 10, max_size: int = 100, 
                default_args: Tuple = None, default_kwargs: Dict = None) -> ObjectPool[T]:
        """
        Ottiene o crea un pool per il tipo di oggetto specificato.
        
        Args:
            object_type: Il tipo di oggetto per cui creare il pool
            initial_capacity: Dimensione iniziale del pool
            max_size: Dimensione massima del pool
            default_args: Argomenti posizionali predefiniti per la creazione di oggetti
            default_kwargs: Argomenti keyword predefiniti per la creazione di oggetti
            
        Returns:
            Un ObjectPool per il tipo specificato
        """
        if object_type not in self.pools:
            self.pools[object_type] = ObjectPool(object_type, initial_capacity, max_size, 
                                              default_args, default_kwargs)
        return self.pools[object_type]
    
    def cache_data(self, key: str, data: Any, ttl: Optional[float] = None) -> None:
        """
        Memorizza dati nella cache per riutilizzo.
        
        Args:
            key: Chiave per identificare i dati
            data: I dati da memorizzare
            ttl: Time-to-live in secondi (None = infinito)
        """
        cache_item = {
            'data': data,
            'created': time.time(),
            'ttl': ttl
        }
        self.cached_data[key] = cache_item
        logger.debug(f"Dati memorizzati nella cache con chiave: {key}")
        
        # Aggiorna statistiche di memoria
        self._update_memory_stats()
    
    def get_cached_data(self, key: str, default: Any = None) -> Any:
        """
        Ottiene dati dalla cache.
        
        Args:
            key: Chiave dei dati da recuperare
            default: Valore di default se la chiave non esiste
            
        Returns:
            I dati memorizzati o il valore di default
        """
        if key in self.cached_data:
            cache_item = self.cached_data[key]
            
            # Controlla se il TTL è scaduto
            if cache_item['ttl'] is not None:
                if time.time() - cache_item['created'] > cache_item['ttl']:
                    # Scaduto, elimina e ritorna il default
                    del self.cached_data[key]
                    self.memory_stats['cache_misses'] += 1
                    return default
            
            # Cache hit
            self.memory_stats['cache_hits'] += 1
            return cache_item['data']
        
        # Cache miss
        self.memory_stats['cache_misses'] += 1
        return default
    
    def _update_memory_stats(self):
        """Aggiorna le statistiche di utilizzo memoria."""
        if self.has_psutil:
            process = psutil.Process(os.getpid())
            current_mem = process.memory_info().rss / (1024 * 1024)  # MB
            self.memory_stats['last_check'] = current_mem
            self.memory_stats['peak'] = max(self.memory_stats['peak'], current_mem)
    
    def get_peak_memory_usage(self):
        """Restituisce il picco di utilizzo memoria in MB."""
        self._update_memory_stats()
        return self.memory_stats['peak']
    
    def get_cache_stats(self):
        """Restituisce le statistiche della cache."""
        return {
            'size': len(self.cached_data),
            'hits': self.memory_stats['cache_hits'],
            'misses': self.memory_stats['cache_misses'],
            'hit_ratio': self.memory_stats['cache_hits'] / 
                        (self.memory_stats['cache_hits'] + self.memory_stats['cache_misses'] or 1)
        }
    
    def clear_cache(self, key: Optional[str] = None) -> None:
        """
        Svuota la cache completamente o per una chiave specifica.
        
        Args:
            key: Se specificato, rimuove solo questa chiave
        """
        if key is not None:
            if key in self.cached_data:
                del self.cached_data[key]
                logger.debug(f"Rimosso dalla cache: {key}")
        else:
            self.cached_data.clear()
            logger.debug("Cache completamente svuotata")
    
    def force_collection(self) -> None:
        """Forza una raccolta garbage completa."""
        pre_count = len(gc.get_objects())
        gc.collect()
        post_count = len(gc.get_objects())
        logger.debug(f"Garbage collection eseguita. Oggetti prima: {pre_count}, dopo: {post_count}")
    
    def clear_all_pools(self) -> None:
        """Svuota tutti i pool di oggetti."""
        for pool in self.pools.values():
            pool.clear()
        logger.debug("Tutti i pool di oggetti sono stati svuotati")
    
    def forced_cleanup(self) -> None:
        """Esegue una pulizia completa e aggressiva della memoria."""
        # Pulisci pool
        self.clear_all_pools()
        
        # Pulisci cache
        self.clear_cache()
        
        # Forza GC più volte per maggiore pulizia
        for _ in range(3):
            collected = gc.collect()
            self.memory_stats['collections'] += collected
        
        logger.info(f"Pulizia aggressiva completata: rimossi {self.memory_stats['collections']} oggetti")

# Istanza globale del memory manager
_memory_manager = None

def get_memory_manager() -> MemoryManager:
    """Restituisce l'istanza globale del memory manager."""
    global _memory_manager
    if _memory_manager is None:
        _memory_manager = MemoryManager()
    return _memory_manager
