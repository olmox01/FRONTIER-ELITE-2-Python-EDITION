"""
Gestisce l'universo di gioco, inclusi sistemi stellari, pianeti e navi
"""
import random
import math
import time
from .vector import Vector3D
from .logger import get_logger
from .memory_manager import get_memory_manager
from .event_system import get_event_system, GameEventType

logger = get_logger()
memory_manager = get_memory_manager()
event_system = get_event_system()

class Star:
    def __init__(self, position, brightness):
        self.position = position
        self.brightness = brightness  # 0.0-1.0
    
    def reset(self, position, brightness):
        """Reset per il pooling degli oggetti."""
        self.position = position
        self.brightness = brightness
        return self


class Planet:
    def __init__(self, position, radius, color_id, name):
        self.position = position
        self.radius = radius
        self.color_id = color_id
        self.name = name
        self.economy = random.choice(["Agricola", "Industriale", "Estrattiva", "Turistica"])
        self.government = random.choice(["Democrazia", "Corporazione", "Anarchia", "Dittatura"])
        self.population = random.randint(100000, 10000000000)
        self.tech_level = random.randint(1, 10)
        self.mass = radius * 1e24  # Massa proporzionale al raggio
        self.type = "planet"  # Tipo per il sistema fisico
        self.hull = 1e12  # Scafo praticamente infinito
        self.max_hull = 1e12
        
        # Parametri orbitali
        self.orbit_distance = 0  # Distanza dal centro del sistema
        self.orbit_speed = 0     # Velocità orbitale
        self.orbit_angle = 0     # Angolo orbitale attuale
        self.orbit_axis = Vector3D(0, 1, 0)  # Asse di rotazione
        self.rotation_period = random.uniform(10, 30) * 3600  # Periodo di rotazione in secondi
        
        # Coordinate locali
        self.local_coords = {}  # Dizionario per memorizzare coordinate relative al pianeta
        
    def get_color(self):
        return self.color_id
    
    def reset(self, position, radius, color_id, name):
        """Reset per il pooling degli oggetti."""
        self.position = position
        self.radius = radius
        self.color_id = color_id
        self.name = name
        self.economy = random.choice(["Agricola", "Industriale", "Estrattiva", "Turistica"])
        self.government = random.choice(["Democrazia", "Corporazione", "Anarchia", "Dittatura"])
        self.population = random.randint(100000, 10000000000)
        self.tech_level = random.randint(1, 10)
        return self
    
    def update_orbit(self, delta_time, global_time):
        """Aggiorna la posizione orbitale in base al tempo globale."""
        if self.orbit_distance <= 0 or self.orbit_speed <= 0:
            return  # Non in orbita
            
        # Calcola nuovo angolo orbitale in base al tempo
        self.orbit_angle += self.orbit_speed * delta_time
        self.orbit_angle %= (2 * math.pi)  # Mantieni tra 0 e 2π
        
        # Calcola nuova posizione basata sull'orbita
        if hasattr(self, 'system_position'):
            x = self.orbit_distance * math.cos(self.orbit_angle)
            z = self.orbit_distance * math.sin(self.orbit_angle)
            self.position = Vector3D(
                self.system_position.x + x,
                self.system_position.y + self.orbit_axis.y * 0.1,
                self.system_position.z + z
            )


class System:
    def __init__(self, position, name):
        self.position = position
        self.name = name
        self.planets = []
        self.stations = []
        self.star_type = random.choice(["O", "B", "A", "F", "G", "K", "M"])
        self.star_size = random.uniform(0.1, 2.0)
        self.mass = self.star_size * 1e30  # Massa proporzionale alla dimensione
        self.type = "star"  # Tipo per il sistema fisico
        self.hull = 1e15  # Scafo infinito
        self.max_hull = 1e15
        self.radius = self.star_size * 10  # Raggio della stella
        
        # Sistema di coordinate locale
        self.local_x = Vector3D(1, 0, 0)
        self.local_y = Vector3D(0, 1, 0)
        self.local_z = Vector3D(0, 0, 1)
        
        # Crea pianeti
        num_planets = random.randint(0, 8)
        logger.debug(f"Generando sistema {name} con {num_planets} pianeti")
        
        for i in range(num_planets):
            orbit_distance = random.uniform(2.0, 40.0) 
            orbit_angle = random.uniform(0, math.pi * 2)
            orbit_speed = 1.0 / (orbit_distance * 100)  # Più lontano = più lenta l'orbita
            
            # Aggiungi varianza all'asse orbitale
            orbit_tilt = random.uniform(-0.2, 0.2)
            orbit_axis = Vector3D(0, 1 + orbit_tilt, 0).normalize()
            
            # Posizione orbitale
            px = math.cos(orbit_angle) * orbit_distance
            py = random.uniform(-0.1, 0.1) * orbit_distance
            pz = math.sin(orbit_angle) * orbit_distance
            
            planet_position = Vector3D(px, py, pz).add(self.position)
            radius = random.uniform(0.3, 2.0)
            
            # Scegli colore basato su tipo (pianeta roccioso o gassoso)
            if orbit_distance < 15:  # Pianeti interni rocciosi
                color = random.choice([1, 3, 4])  # Rosso, giallo, blu
            else:  # Pianeti esterni gassosi
                color = random.choice([2, 5, 6])  # Verde, magenta, ciano
            
            planet_name = f"{self.name} {chr(65+i)}"  # Nome tipo "Alpha Centauri A"
            planet = Planet(planet_position, radius, color, planet_name)
            
            # Memorizza parametri orbitali
            planet.orbit_distance = orbit_distance
            planet.orbit_speed = orbit_speed
            planet.orbit_angle = orbit_angle
            planet.orbit_axis = orbit_axis
            planet.system_position = Vector3D(self.position.x, self.position.y, self.position.z)
            
            self.planets.append(planet)
            
        # Aggiungi una stazione spaziale se ci sono pianeti
        if num_planets > 0:
            # Posiziona la stazione vicino a un pianeta casuale
            if self.planets:
                planet = random.choice(self.planets)
                station_distance = random.uniform(0.5, 1.5)
                station_angle = random.uniform(0, math.pi * 2)
                
                sx = planet.position.x + math.cos(station_angle) * station_distance
                sy = planet.position.y + random.uniform(-0.1, 0.1)
                sz = planet.position.z + math.sin(station_angle) * station_distance
                
                from .station import Station
                station = Station(Vector3D(sx, sy, sz), f"Stazione {self.name}")
                
                # La stazione segue il pianeta (è in orbita relativa)
                station.orbiting_planet = planet
                
                self.stations.append(station)
    
    def get_star_color(self):
        """Restituisce il colore della stella in base al suo tipo."""
        star_colors = {
            "O": 4,  # Blu
            "B": 4,  # Blu
            "A": 7,  # Bianco
            "F": 7,  # Bianco
            "G": 3,  # Giallo
            "K": 3,  # Giallo
            "M": 1,  # Rosso
        }
        return star_colors.get(self.star_type, 7)
    
    def update(self, delta_time, global_time):
        """Aggiorna il sistema, pianeti e stazioni."""
        # Aggiorna ogni pianeta
        for planet in self.planets:
            planet.update_orbit(delta_time, global_time)
            
        # Aggiorna le stazioni (mantienile in orbita relativa ai pianeti)
        for station in self.stations:
            if hasattr(station, 'orbiting_planet'):
                planet = station.orbiting_planet
                
                # Calcola posizione relativa dalla stazione al pianeta
                rel_pos = station.position.subtract(planet.position)
                
                # Ruota leggermente la posizione relativa
                station_orbit_speed = 0.0001
                angle = station_orbit_speed * delta_time
                
                # Ruota attorno all'asse Y
                x = rel_pos.x
                z = rel_pos.z
                new_x = x * math.cos(angle) - z * math.sin(angle)
                new_z = x * math.sin(angle) + z * math.cos(angle)
                
                # Aggiorna la posizione della stazione
                station.position = Vector3D(
                    planet.position.x + new_x,
                    planet.position.y + rel_pos.y,
                    planet.position.z + new_z
                )


class Universe:
    def __init__(self):
        self.systems = []
        self.stars = []
        self.ships = []
        
        # Crea pool di oggetti con valori di default appropriati
        default_vector = Vector3D(0, 0, 0)
        self.star_pool = memory_manager.get_pool(Star, 100, 2000, 
                                                default_args=(default_vector, 0.5))
        self.planet_pool = memory_manager.get_pool(Planet, 20, 200, 
                                                  default_args=(default_vector, 1.0, 1, "Default"))
        
        logger.info("Inizializzazione dell'universo di gioco")
        self.generate_universe()
        self.generate_background_stars()
        logger.info(f"Universo generato: {len(self.systems)} sistemi, {len(self.stars)} stelle")
        
        # Aggiungi l'orologio globale per le orbite
        self.global_time = time.time()
        self.last_update_time = self.global_time
    
    def generate_universe(self):
        """Genera i sistemi stellari dell'universo."""
        system_names = [
            "Alpha Centauri", "Barnard's Star", "Wolf 359", "Lalande 21185",
            "Epsilon Eridani", "Lacaille 8760", "Ross 154", "Ross 248",
            "Epsilon Indi", "Tau Ceti", "Groombridge 34", "Eta Cassiopeiae",
            "36 Ophiuchi", "BD+05 1668", "Lacaille 9352", "Struve 2398",
            "Groombridge 1618", "Epsilon Cephei", "Procyon", "61 Cygni"
        ]
        
        # Genera una griglia di sistemi
        for i in range(20):
            # Posizione con un po' di casualità
            pos_x = random.uniform(-100, 100)
            pos_y = random.uniform(-5, 5)  # Universo relativamente piatto
            pos_z = random.uniform(-100, 100)
            
            position = Vector3D(pos_x, pos_y, pos_z)
            
            # Evita sistemi troppo vicini
            too_close = False
            for system in self.systems:
                if position.distance(system.position) < 10.0:
                    too_close = True
                    break
            
            if not too_close:
                name = system_names[i] if i < len(system_names) else f"Sistema {i+1}"
                self.systems.append(System(position, name))
    
    def generate_background_stars(self):
        """Genera le stelle di sfondo per la scena spaziale."""
        for _ in range(1000):
            # Distribuisci le stelle in una sfera attorno all'origine
            theta = random.uniform(0, math.pi * 2)
            phi = random.uniform(0, math.pi)
            distance = random.uniform(50, 500)
            
            x = distance * math.sin(phi) * math.cos(theta)
            y = distance * math.sin(phi) * math.sin(theta)
            z = distance * math.cos(phi)
            
            position = Vector3D(x, y, z)
            brightness = random.uniform(0.2, 1.0)
            
            # Usa il pool di stelle
            star = self.star_pool.acquire(position, brightness)
            self.stars.append(star)
    
    def get_current_system(self, position):
        """Trova il sistema stellare più vicino alla posizione data."""
        closest_system = None
        min_distance = float('inf')
        
        for system in self.systems:
            distance = position.distance(system.position)
            if distance < min_distance:
                min_distance = distance
                closest_system = system
        
        # Consideriamo la nave nel sistema se è entro 50 unità
        if closest_system and min_distance <= 50:
            # Se memorizzato un sistema precedente, pubblica evento di cambio sistema
            if hasattr(position, 'last_system') and position.last_system != closest_system:
                event_system.publish(GameEventType.SYSTEM_ENTERED, {
                    'entity': position,
                    'old_system': position.last_system,
                    'new_system': closest_system,
                    'position': position
                })
                
            # Memorizziamo l'ultimo sistema per rilevare cambiamenti
            position.last_system = closest_system
            return closest_system
        
        # Se esce dal sistema
        if hasattr(position, 'last_system') and position.last_system is not None:
            event_system.publish(GameEventType.SYSTEM_EXITED, {
                'entity': position,
                'old_system': position.last_system,
                'position': position
            })
            position.last_system = None
            
        return None
    
    def get_visible_stars(self, position, orientation):
        """Restituisce le stelle visibili dalla posizione attuale."""
        visible_stars = []
        forward = orientation.get_forward_vector()
        
        for star in self.stars:
            # Calcola il vettore dalla posizione alla stella
            to_star = star.position.subtract(position)
            distance = to_star.length()
            
            # Normalizziamo il vettore
            if distance > 0:
                to_star = to_star.scale(1.0 / distance)
                
                # La stella è "davanti" al giocatore? (prodotto scalare positivo)
                if to_star.dot(forward) > 0.7:  # Campo visivo di circa 90 gradi
                    visible_stars.append(star)
        
        return visible_stars
    
    def get_nearby_ships(self, position):
        """Restituisce le navi vicine alla posizione data."""
        nearby_ships = []
        
        for ship in self.ships:
            if position.distance(ship.position) < 100:  # 100 unità arbitrarie
                nearby_ships.append(ship)
        
        return nearby_ships
    
    def add_ship(self, ship, position=None):
        """Aggiunge una nave all'universo."""
        if position:
            ship.position = position
        self.ships.append(ship)
        
        # Pubblica evento
        event_system.publish(GameEventType.OBJECT_SPAWNED, {
            'type': 'ship',
            'object': ship,
            'position': ship.position
        })
        
    def remove_ship(self, ship):
        """Rimuove una nave dall'universo."""
        if ship in self.ships:
            self.ships.remove(ship)
            
            # Pubblica evento
            event_system.publish(GameEventType.OBJECT_DESTROYED, {
                'type': 'ship',
                'object': ship,
                'position': ship.position
            })
    
    def update(self, delta_time):
        """Aggiorna l'universo e tutti i suoi oggetti."""
        # Aggiorna l'orologio globale
        current_time = time.time()
        self.global_time += delta_time
        
        # Aggiorna ogni sistema stellare
        for system in self.systems:
            system.update(delta_time, self.global_time)
