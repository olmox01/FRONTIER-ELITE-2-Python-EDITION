"""
Gestisce l'interfaccia utente del gioco
"""
import curses
import time
from .logger import get_logger
from .event_system import get_event_system, GameEventType
from .memory_manager import get_memory_manager
from .config import get_config

logger = get_logger()
event_system = get_event_system()
memory_manager = get_memory_manager()
config = get_config()

class UserInterface:
    def __init__(self, stdscr, width, height):
        self.stdscr = stdscr
        self.width = width
        self.height = height
        self.last_render_time = 0
        self.cached_controls = {}
        self.prev_view = None
        self.frame_counter = 0
        self.ui_dirty = True
        self.cached_border = []         # Cache per la cornice
        self.double_buffer_enabled = True  # Usa double buffering
        
        # Configurazione avanzata per UI
        self.refresh_rate = config.get("ui.refresh_rate", 30)  # Hz
        self.refresh_interval = 1.0 / self.refresh_rate
        self.ui_message_duration = config.get("ui.message_duration", 5.0)  # Secondi
        self.use_color_pairs = {}  # Cache per coppie di colori
        
        # Controllo sfarfallio
        self.last_frame_content = {}  # Cache contenuto ultimo frame
        self.ui_change_count = 0      # Contatore modifiche UI
        
        # Sottoscrizione agli eventi UI
        event_system.subscribe(GameEventType.NOTIFICATION, self.on_notification)
        event_system.subscribe(GameEventType.VIEW_CHANGE, self.on_view_change)
        event_system.subscribe(GameEventType.PLAYER_DAMAGE, self.on_player_damage)
        event_system.subscribe(GameEventType.PLAYER_JUMP, self.on_player_jump)
        event_system.subscribe(GameEventType.PLAYER_DOCK, self.on_player_dock)
        
        # Cache la cornice una sola volta
        self._cache_border()
        
        # Inizializzazione del colore avanzato
        self._setup_advanced_colors()
        
        logger.info(f"UI inizializzata con dimensioni {width}x{height}, refresh rate {self.refresh_rate}Hz")
    
    def _setup_advanced_colors(self):
        """Inizializza il supporto per 256 colori se disponibile."""
        try:
            # Verifica se il terminale supporta 256 colori
            if curses.can_change_color() and curses.COLORS >= 256:
                logger.info(f"Terminale supporta {curses.COLORS} colori")
                
                # Crea alcune coppie di colori avanzate (da 8 a 16)
                for i in range(8, 16):
                    curses.init_pair(i, i, curses.COLOR_BLACK)
                    
                # Registra che il supporto avanzato è disponibile
                self.advanced_colors_available = True
            else:
                self.advanced_colors_available = False
                logger.info("Terminale non supporta colori avanzati, usando modalità compatibilità")
        except Exception as e:
            logger.error(f"Errore nell'inizializzazione colori avanzati: {str(e)}")
            self.advanced_colors_available = False
    
    def _cache_border(self):
        """Pre-cache i caratteri della cornice per evitare sfarfallio."""
        # Cache orizzontale superiore e inferiore
        for x in range(self.width-1):
            self.cached_border.append((0, x, '-'))  # Superiore
            if x < self.width-2:  # Sicurezza per ultima colonna
                self.cached_border.append((self.height-1, x, '-'))  # Inferiore
        
        # Cache verticale sinistra e destra
        for y in range(self.height-1):
            self.cached_border.append((y, 0, '|'))  # Sinistra
            if y < self.height-2:  # Sicurezza per ultima riga
                self.cached_border.append((y, self.width-1, '|'))  # Destra
    
    def _safe_addstr(self, y, x, text, attr=0):
        """Sicuro addstr con gestione errori out-of-bounds."""
        try:
            # Verifica se il contenuto è cambiato rispetto all'ultimo frame
            key = (y, x, text)
            last_content = self.last_frame_content.get(key)
            
            if last_content != text:
                self.stdscr.addstr(y, x, text, attr)
                self.last_frame_content[key] = text
                self.ui_change_count += 1
        except curses.error:
            pass  # Ignora errori di posizionamento fuori schermo
    
    def _safe_addch(self, y, x, char, attr=0):
        """Sicuro addch con gestione errori out-of-bounds."""
        try:
            # Verifica se il contenuto è cambiato rispetto all'ultimo frame
            key = (y, x, char)
            last_content = self.last_frame_content.get(key)
            
            if last_content != char:
                self.stdscr.addch(y, x, char, attr)
                self.last_frame_content[key] = char
                self.ui_change_count += 1
        except curses.error:
            pass  # Ignora errori di posizionamento fuori schermo
    
    def on_notification(self, event_type, data):
        """Gestisce notifiche in-game."""
        if data and 'message' in data:
            self.show_message(data['message'], data.get('color', 7))
            self.ui_dirty = True
    
    def on_view_change(self, event_type, data):
        """Gestisce cambi di vista."""
        if data:
            old_view = data.get('old_view')
            new_view = data.get('new_view')
            logger.debug(f"UI: cambio vista da {old_view} a {new_view}")
            
            # Invalida la cache e forza refresh
            if new_view in self.cached_controls:
                del self.cached_controls[new_view]
            
            # Reset completo UI per cambio vista
            self.last_frame_content.clear()
            self.ui_dirty = True
    
    def on_player_damage(self, event_type, data):
        """Reagisce ai danni del giocatore con UI feedback."""
        if 'new_hull' in data:
            hull = data['new_hull']
            if hull < 30:
                self.show_message(f"AVVISO: Scafo critico ({hull:.1f}%)!", 1)  # Rosso
            self.ui_dirty = True
            
    def on_player_jump(self, event_type, data):
        """Feedback UI per salto iperspaziale."""
        if data and 'to_system' in data:
            system = data['to_system']
            self.show_message(f"Salto completato: {system.name}", 3)  # Giallo
            self.ui_dirty = True
            
    def on_player_dock(self, event_type, data):
        """Feedback UI per attracco."""
        if data and 'station' in data:
            station = data['station']
            self.show_message(f"Attraccato a: {station.name}", 2)  # Verde
            self.ui_dirty = True
    
    def render(self, stdscr, game_state):
        """Renderizza l'interfaccia utente basata sullo stato di gioco."""
        # Throttling del rendering UI per evitare sfarfallio
        current_time = time.time()
        if current_time - self.last_render_time < self.refresh_interval:
            return
            
        # Controlla se è necessario aggiornare l'UI
        current_view = game_state.current_view
        view_changed = current_view != self.prev_view
        
        # Aggiorna solo se necessario (vista cambiata o UI sporca)
        if view_changed or self.ui_dirty:
            # Reset contatore modifiche UI
            self.ui_change_count = 0
            
            # Aggiorna timestamp ultimo rendering
            self.last_render_time = current_time
            self.prev_view = current_view
            self.ui_dirty = False
            
            # Tracciamento per debugging
            logger.debug(f"Rendering UI per vista {current_view}")
            
            # Disegna la cornice dalla cache
            for y, x, char in self.cached_border:
                self._safe_addch(y, x, char, curses.color_pair(7))
            
            # Mostra messaggi più recenti
            messages_to_render = []
            for i, (text, color, timestamp) in enumerate(game_state.messages):
                if current_time - timestamp < self.ui_message_duration:
                    messages_to_render.append((i, text, color))
            
            # Renderizza messaggi
            for i, text, color in messages_to_render:
                self._safe_addstr(5 + i, 2, text, curses.color_pair(color))
            
            # Mostra i controlli completi in basso basati sulla vista corrente
            controls = self.get_controls_for_view(current_view)
            
            # Calcola altezza della barra dei comandi
            command_bar_y = self.height - 2  # Posizione verticale fissa per i controlli
            
            # Renderizza su due righe se necessario
            if len(controls) > 5:  # Arbitrario, può essere regolato
                # Prima riga di controlli
                x_pos = 2
                count = 0
                for key, desc in list(controls.items())[:(len(controls)//2)]:
                    text = f"{key}: {desc}"
                    if x_pos + len(text) + 2 < self.width:
                        self._safe_addstr(command_bar_y - 1, x_pos, text, curses.color_pair(3))
                        x_pos += len(text) + 4
                        count += 1
                
                # Seconda riga di controlli
                x_pos = 2
                for key, desc in list(controls.items())[count:]:
                    text = f"{key}: {desc}"
                    if x_pos + len(text) + 2 < self.width:
                        self._safe_addstr(command_bar_y, x_pos, text, curses.color_pair(3))
                        x_pos += len(text) + 4
            else:
                # Singola riga di controlli
                x_pos = 2
                for key, desc in controls.items():
                    text = f"{key}: {desc}"
                    if x_pos + len(text) + 2 < self.width:
                        self._safe_addstr(command_bar_y, x_pos, text, curses.color_pair(3))
                        x_pos += len(text) + 4
            
            # Debug - mostra statistics
            if config.get("ui.show_debug_info", False):
                debug_info = f"UI changes: {self.ui_change_count}"
                self._safe_addstr(1, 2, debug_info, curses.color_pair(4))
        
        # Incrementa contatore frame anche se non abbiamo renderizzato
        self.frame_counter += 1
    
    def render_performance_overlay(self, stdscr, performance_monitor):
        """Renderizza un overlay con le informazioni di performance."""
        if not performance_monitor or not performance_monitor.enabled:
            return
            
        stats = performance_monitor.get_stats()
        
        # Determina posizione per l'overlay
        overlay_width = 40
        overlay_x = 2
        overlay_y = 2
        
        try:
            # Intestazione
            self._safe_addstr(overlay_y, overlay_x, "=== Performance Stats ===", curses.color_pair(7))
            
            # FPS
            if "fps" in stats:
                fps_str = f"FPS: {stats['fps']['current']:.1f} (Avg: {stats['fps']['avg']:.1f})"
                self._safe_addstr(overlay_y + 2, overlay_x, fps_str, curses.color_pair(3))
            
            # Frame Time
            if "frame_time" in stats:
                frame_str = f"Frame: {stats['frame_time']['current']:.1f}ms (Avg: {stats['frame_time']['avg']:.1f}ms)"
                self._safe_addstr(overlay_y + 3, overlay_x, frame_str, curses.color_pair(3))
            
            # Memoria
            if "memory_usage" in stats:
                mem_str = f"Memory: {stats['memory_usage']['current']:.1f} MB"
                self._safe_addstr(overlay_y + 4, overlay_x, mem_str, curses.color_pair(6))
            
            # CPU
            if "cpu_usage" in stats:
                cpu_str = f"CPU: {stats['cpu_usage']['current']:.1f}%"
                self._safe_addstr(overlay_y + 5, overlay_x, cpu_str, curses.color_pair(6))
            
            # Rendering Time
            if "render_time" in stats:
                render_str = f"Render: {stats['render_time']['current']:.1f}ms"
                self._safe_addstr(overlay_y + 6, overlay_x, render_str, curses.color_pair(5))
        except curses.error:
            pass
    
    def get_controls_for_view(self, view):
        """Restituisce i controlli aggiornati per la vista corrente con caching."""
        # Usa la cache se disponibile
        if view in self.cached_controls:
            return self.cached_controls[view]
        
        # Se non in cache, genera i controlli AGGIORNATI
        if view == "space":
            controls = {
                "W/A/S/D": "Movimento",
                "Q/E": "Rollio", 
                "R/F": "Vel+/Vel-",
                "M": "Mappa",
                "B": "Attracca", 
                "T": "Armi",
                "G": "Salva",
                "H": "Scudi",
                "X": "Esci"
            }
        elif view == "starmap":
            controls = {
                "Frecce": "Naviga", 
                "J": "Salto", 
                "M/ESC": "Ritorna",
                "+/-": "Zoom"
            }
        elif view == "station":
            controls = {
                "1": "Mercato",
                "2": "Equipaggia",
                "3": "Missioni", 
                "4": "Notizie",
                "5": "Esci",
                "ESC": "Ritorna"
            }
        else:
            controls = {}
            
        # Salva nella cache
        self.cached_controls[view] = controls
        return controls
    
    def show_message(self, message, color=7):
        """Mostra un messaggio temporaneo all'utente."""
        max_length = self.width - 4
        if len(message) > max_length:
            message = message[:max_length-3] + "..."
        
        # Previene la ricorsione pubblicando l'evento solo se non è già una notifica UI
        if not hasattr(self, '_in_notification'):
            try:
                self._in_notification = True
                # Aggiunge il messaggio allo stato di gioco invece di renderizzarlo direttamente
                event_system.publish(GameEventType.NOTIFICATION, {
                    'type': 'ui_message',
                    'message': message,
                    'color': color
                })
            finally:
                self._in_notification = False
        else:
            # Se già stiamo gestendo una notifica, evita di pubblicare un altro evento
            logger.debug(f"Evitata ricorsione per il messaggio: {message}")
            
    def show_dialog(self, title, content, options=None):
        """Mostra una finestra di dialogo."""
        # Calcola dimensioni e posizione del dialogo
        dialog_width = min(60, self.width - 4)
        lines = content.split('\n')
        dialog_height = len(lines) + 4 + (2 if options else 0)
        
        start_y = (self.height - dialog_height) // 2
        start_x = (self.width - dialog_width) // 2
        
        # Usa una tupla di coordinate per riempire il background
        dialog_area = []
        for y in range(start_y, start_y + dialog_height):
            for x in range(start_x, start_x + dialog_width):
                if (y == start_y or y == start_y + dialog_height - 1 or 
                    x == start_x or x == start_x + dialog_width - 1):
                    # Caratteri per il bordo
                    char = '+' if (y == start_y or y == start_y + dialog_height - 1) and \
                                 (x == start_x or x == start_x + dialog_width - 1) else \
                           '-' if y == start_y or y == start_y + dialog_height - 1 else '|'
                    dialog_area.append((y, x, char, 6))
                else:
                    # Spazio per riempire il background
                    dialog_area.append((y, x, ' ', 0))
        
        # Renderizza l'area di dialogo in maniera efficiente
        for y, x, char, color_pair in dialog_area:
            self._safe_addch(y, x, char, curses.color_pair(color_pair))
        
        # Disegna il titolo
        title_x = start_x + (dialog_width - len(title)) // 2
        self._safe_addstr(start_y, title_x, f" {title} ", curses.color_pair(3))
        
        # Disegna il contenuto
        for i, line in enumerate(lines):
            if len(line) > dialog_width - 4:
                line = line[:dialog_width - 7] + "..."
            self._safe_addstr(start_y + 2 + i, start_x + 2, line, curses.color_pair(7))
        
        # Disegna le opzioni
        if options:
            options_text = " | ".join(f"{i+1}. {opt}" for i, opt in enumerate(options))
            options_x = start_x + (dialog_width - len(options_text)) // 2
            self._safe_addstr(start_y + dialog_height - 2, options_x, 
                             options_text, curses.color_pair(3))
        
        # Forza refresh per mostrare il dialogo immediatamente
        self.stdscr.refresh()
        self.ui_dirty = True
    
    def clear_caches(self):
        """Pulisce le cache UI."""
        self.cached_controls.clear()
        self.last_frame_content.clear()
        self.ui_dirty = True
        logger.debug("Cache UI pulite")
