"""
Implementazione avanzata di vettori 3D e matrici per grafica vettoriale
Supporta calcoli ad alta precisione e ottimizzazioni per fisica spaziale
"""
import math
import numpy as np  # Aggiungiamo NumPy per calcoli ad alta precisione
from decimal import Decimal, getcontext
from .logger import get_logger
from .config import get_config

logger = get_logger()
config = get_config()

# Imposta la precisione per calcoli ad alta precisione
getcontext().prec = 28

class Vector3D:
    """
    Vettore 3D con supporto per calcoli ad alta precisione
    e compatibilità con NumPy per ottimizzazioni.
    """
    def __init__(self, x=0.0, y=0.0, z=0.0):
        # Usiamo float come tipo base ma con supporto per conversione a Decimal per alta precisione
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)
        self._numpy_array = None  # Lazy initialization
    
    @property
    def numpy(self):
        """Ottiene una rappresentazione NumPy del vettore per calcoli ottimizzati."""
        if self._numpy_array is None:
            self._numpy_array = np.array([self.x, self.y, self.z], dtype=np.float64)
        return self._numpy_array
    
    def as_decimal(self):
        """Converte le coordinate in Decimal per calcoli ad altissima precisione."""
        return Vector3D(Decimal(str(self.x)), Decimal(str(self.y)), Decimal(str(self.z)))
    
    def add(self, other):
        """Somma due vettori."""
        return Vector3D(self.x + other.x, self.y + other.y, self.z + other.z)
    
    def subtract(self, other):
        """Sottrae due vettori."""
        return Vector3D(self.x - other.x, self.y - other.y, self.z - other.z)
    
    def scale(self, scalar):
        """Scala un vettore per uno scalare."""
        return Vector3D(self.x * scalar, self.y * scalar, self.z * scalar)
    
    def dot(self, other):
        """Prodotto scalare tra due vettori."""
        return self.x * other.x + self.y * other.y + self.z * other.z
    
    def cross(self, other):
        """Prodotto vettoriale tra due vettori."""
        return Vector3D(
            self.y * other.z - self.z * other.y,
            self.z * other.x - self.x * other.z,
            self.x * other.y - self.y * other.x
        )
    
    def length(self):
        """Calcola la lunghezza del vettore."""
        return math.sqrt(self.x * self.x + self.y * self.y + self.z * self.z)
    
    def length_squared(self):
        """Calcola il quadrato della lunghezza (più efficiente per confronti)."""
        return self.x * self.x + self.y * self.y + self.z * self.z
    
    def normalize(self):
        """Normalizza il vettore a lunghezza unitaria."""
        length = self.length()
        if length > 1e-10:  # Evita divisione per quasi-zero
            return self.scale(1.0 / length)
        logger.debug("Tentativo di normalizzare un vettore di lunghezza quasi zero")
        return Vector3D()
    
    def distance(self, other):
        """Calcola la distanza tra due punti/vettori."""
        return self.subtract(other).length()
    
    def distance_squared(self, other):
        """Calcola il quadrato della distanza (più efficiente)."""
        return self.subtract(other).length_squared()
    
    def to_astronomical_units(self):
        """Converte coordinate a unità astronomiche per calcoli spaziali."""
        au = 149597870700  # 1 AU in metri
        return Vector3D(self.x / au, self.y / au, self.z / au)
    
    def from_spherical(r, theta, phi):
        """Crea un vettore da coordinate sferiche."""
        x = r * math.sin(phi) * math.cos(theta)
        y = r * math.sin(phi) * math.sin(theta)
        z = r * math.cos(phi)
        return Vector3D(x, y, z)
    
    def to_tuple(self):
        """Converte il vettore in tupla."""
        return (self.x, self.y, self.z)
    
    def __str__(self):
        return f"Vector3D({self.x:.2f}, {self.y:.2f}, {self.z:.2f})"


class Matrix3D:
    """Matrice 3x3 ottimizzata per trasformazioni 3D."""
    
    def __init__(self, data=None):
        if data is None:
            # Inizializza come matrice identità
            self.matrix = np.identity(3, dtype=np.float64)
        else:
            # Converti input in array NumPy
            self.matrix = np.array(data, dtype=np.float64)
    
    @staticmethod
    def create_rotation_x(angle):
        """Crea una matrice di rotazione attorno all'asse X."""
        rad = math.radians(angle)
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)
        
        return Matrix3D([
            [1.0, 0.0, 0.0],
            [0.0, cos_a, -sin_a],
            [0.0, sin_a, cos_a]
        ])
    
    @staticmethod
    def create_rotation_y(angle):
        """Crea una matrice di rotazione attorno all'asse Y."""
        rad = math.radians(angle)
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)
        
        return Matrix3D([
            [cos_a, 0.0, sin_a],
            [0.0, 1.0, 0.0],
            [-sin_a, 0.0, cos_a]
        ])
    
    @staticmethod
    def create_rotation_z(angle):
        """Crea una matrice di rotazione attorno all'asse Z."""
        rad = math.radians(angle)
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)
        
        return Matrix3D([
            [cos_a, -sin_a, 0.0],
            [sin_a, cos_a, 0.0],
            [0.0, 0.0, 1.0]
        ])
    
    def multiply(self, other):
        """Moltiplica questa matrice per un'altra."""
        result = Matrix3D()
        # Ottimizzazione con NumPy per il prodotto matriciale
        result.matrix = np.matmul(self.matrix, other.matrix)
        return result
    
    def transform_point(self, point):
        """Trasforma un punto 3D utilizzando questa matrice."""
        # Ottimizzazione con NumPy per trasformazione vettoriale
        vec = np.array([point.x, point.y, point.z], dtype=np.float64)
        transformed = np.matmul(self.matrix, vec)
        return Vector3D(transformed[0], transformed[1], transformed[2])


class Orientation:
    """Rappresentazione dell'orientamento con quaternioni per evitare gimbal lock."""
    
    def __init__(self, pitch=0.0, yaw=0.0, roll=0.0):
        self.pitch = pitch  # X
        self.yaw = yaw      # Y
        self.roll = roll    # Z
        
        # Usiamo sia quaternioni che matrici per diverse esigenze
        self.quaternion = self._euler_to_quaternion(pitch, yaw, roll)
        self.matrix = None
        self.update_matrix()
    
    def _euler_to_quaternion(self, pitch, yaw, roll):
        """Converte angoli di Eulero in quaternione."""
        # Converte in radianti
        pitch_rad = math.radians(pitch)
        yaw_rad = math.radians(yaw)
        roll_rad = math.radians(roll)
        
        # Calcola seni e coseni
        cy = math.cos(yaw_rad * 0.5)
        sy = math.sin(yaw_rad * 0.5)
        cp = math.cos(pitch_rad * 0.5)
        sp = math.sin(pitch_rad * 0.5)
        cr = math.cos(roll_rad * 0.5)
        sr = math.sin(roll_rad * 0.5)
        
        # Calcola componenti quaternione
        w = cr * cp * cy + sr * sp * sy
        x = sr * cp * cy - cr * sp * sy
        y = cr * sp * cy + sr * cp * sy
        z = cr * cp * sy - sr * sp * cy
        
        return [w, x, y, z]
    
    def _quaternion_to_matrix(self, q):
        """Converte quaternione in matrice di rotazione."""
        w, x, y, z = q
        
        # Matrice di rotazione dal quaternione
        return Matrix3D([
            [1 - 2*y*y - 2*z*z, 2*x*y - 2*w*z, 2*x*z + 2*w*y],
            [2*x*y + 2*w*z, 1 - 2*x*x - 2*z*z, 2*y*z - 2*w*x],
            [2*x*z - 2*w*y, 2*y*z + 2*w*x, 1 - 2*x*x - 2*y*y]
        ])
    
    def update_matrix(self):
        """Aggiorna la matrice di rotazione basata sul quaternione."""
        self.matrix = self._quaternion_to_matrix(self.quaternion)
    
    def rotate(self, delta_pitch, delta_yaw, delta_roll):
        """Ruota l'orientamento evitando gimbal lock."""
        self.pitch += delta_pitch
        self.yaw += delta_yaw
        self.roll += delta_roll
        
        # Mantieni il pitch nei limiti di ±90 gradi per evitare gimbal lock
        self.pitch = max(-89.9, min(89.9, self.pitch))
        
        # Normalizza lo yaw e il roll in 0-360
        self.yaw %= 360
        self.roll %= 360
        
        # Aggiorna il quaternione e la matrice
        self.quaternion = self._euler_to_quaternion(self.pitch, self.yaw, self.roll)
        self.update_matrix()
    
    def transform_point(self, point):
        """Trasforma un punto usando la matrice di rotazione corrente."""
        return self.matrix.transform_point(point)
    
    def get_forward_vector(self):
        """Restituisce il vettore di direzione (avanti)."""
        w, x, y, z = self.quaternion
        
        # Calcola il vettore avanti (0,0,-1) trasformato dal quaternione
        return Vector3D(
            2 * (x*z + w*y),
            2 * (y*z - w*x),
            1 - 2 * (x*x + y*y)
        ).normalize()
    
    def get_right_vector(self):
        """Restituisce il vettore destro."""
        w, x, y, z = self.quaternion
        
        # Calcola il vettore destro (1,0,0) trasformato dal quaternione
        return Vector3D(
            1 - 2 * (y*y + z*z),
            2 * (x*y + w*z),
            2 * (x*z - w*y)
        ).normalize()
    
    def get_up_vector(self):
        """Restituisce il vettore su."""
        w, x, y, z = self.quaternion
        
        # Calcola il vettore su (0,1,0) trasformato dal quaternione
        return Vector3D(
            2 * (x*y - w*z),
            1 - 2 * (x*x + z*z),
            2 * (y*z + w*x)
        ).normalize()
