#!/usr/bin/env python3
"""
Frontier Elite 2 - ASCII Edition
Un remake di Frontier Elite 2 per terminale ASCII
"""
import curses
import time
import sys
import os

# Assicuriamo che la directory corrente sia nel path di Python
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from engine.renderer import ASCIIRenderer
from engine.universe import Universe
from engine.ship import PlayerShip
from engine.ui import UserInterface
from engine.game_state import GameState
from engine.logger import get_logger, LogLevel
from engine.game_loop import GameLoop
from engine.config import get_config
from engine.memory_manager import get_memory_manager
from engine.event_system import get_event_system, GameEventType
from engine.save_system import get_save_system
# Import dei gestori di eventi (registrano automaticamente i listener)
from engine.event_handlers import game_event_logger, auto_save_handler
from engine.menu_system import get_menu_system  # Aggiungi questo import

def main(stdscr):
    # Inizializza tutti i sistemi di base
    logger = get_logger()
    config = get_config()
    memory_manager = get_memory_manager()
    event_system = get_event_system()
    save_system = get_save_system()
    
    logger.info("Avvio di Frontier Elite 2 - ASCII Edition")
    
    # Inizializzazione del curses migliorata
    curses.start_color()
    curses.use_default_colors()
    curses.curs_set(0)  # Nascondi il cursore
    stdscr.timeout(50)  # Imposta il timeout per getch
    
    # Inizializza i colori standard
    for i in range(1, 8):
        curses.init_pair(i, i, curses.COLOR_BLACK)
    
    # Aggiungi colori extra per effetti migliori
    curses.init_pair(8, 8, curses.COLOR_BLACK)  # Grigio
    
    # Prova a inizializzare colori avanzati se supportati
    try:
        if curses.can_change_color() and curses.COLORS >= 16:
            for i in range(8, 16):
                curses.init_pair(i + 8, i, curses.COLOR_BLACK)
            logger.info(f"Supporto colori avanzati attivato: {curses.COLORS} colori")
    except Exception as e:
        logger.warning(f"Impossibile inizializzare colori avanzati: {e}")
    
    # Ottieni le dimensioni del terminale
    height, width = stdscr.getmaxyx()
    
    # Inizializza i componenti di gioco
    renderer = ASCIIRenderer(width, height)
    universe = Universe()
    player = PlayerShip()
    game_state = GameState(universe, player)
    ui = UserInterface(stdscr, width, height - 2)  # Riduci l'altezza UI per lasciare spazio ai comandi
    
    # Inizializza il game loop con le impostazioni dalla configurazione
    target_fps = config.get("gameplay.target_fps", 30)
    show_fps = config.get("gameplay.show_fps", True)
    game_loop = GameLoop(target_fps)
    
    # Inizializza il sistema di menu
    menu_system = get_menu_system(stdscr)
    menu_system.update_command_menu("space")  # Imposta i comandi per la vista iniziale
    
    # Pubblica evento di avvio del gioco con informazioni complete
    event_system.publish(GameEventType.GAME_START, {
        'time': time.time(),
        'config': config,
        'terminal_size': (width, height),
        'fps_target': target_fps,
        'game_state': game_state.__dict__  # Passa un dizionario invece dell'oggetto completo
    })
    
    # Avvia il game loop
    game_loop.start()
    
    # Imposta la pulizia memoria all'uscita
    try:
        logger.info("Inizio game loop")
        
        # Principali contatori per profiling
        frame_count = 0
        last_profile_time = time.time()
        
        while game_loop.should_continue():
            # Calcola il delta time in modo preciso
            delta_time = game_loop.begin_frame()
            
            # Gestione dell'input
            key = stdscr.getch()
            
            # Prima dai la priorità al menu system per gestire l'input
            input_handled = menu_system.handle_input(key)
            
            # Se il menu non ha gestito l'input, passalo al gioco
            if not input_handled and key != -1:
                # Timer-based auto-save
                # Se è passato abbastanza tempo dall'ultimo salvataggio
                current_time = time.time()
                if current_time - save_system.last_save_time > save_system.auto_save_interval:
                    save_system.save_game(slot="auto")
                
                # Gestione dei controlli speciali
                if key == ord('t'):
                    if player.fire_weapon():
                        game_state.add_message("Arma primaria attivata", 3)
                elif key == ord('g'):
                    game_state.add_message("Salvataggio in corso...", 6)
                    event_system.publish(GameEventType.GAME_SAVE, {'type': 'manual'})
                elif key == ord('h'):
                    player.take_damage(10, "test")
                    game_state.add_message(f"Danno simulato! Scafo: {player.hull:.1f}%", 1)
                elif key == ord('x'):  # Uscita
                    logger.info("Richiesta di uscita ricevuta")
                    game_loop.stop()
            
            # Aggiorna lo stato di gioco con il delta time accurato
            game_state.update(key, delta_time)
            
            # Aggiorna il menu system quando la vista cambia
            if game_state.current_view != menu_system._current_view:
                menu_system.update_view(game_state.current_view)
            
            # Aggiorna le dimensioni in caso di ridimensionamento
            current_height, current_width = stdscr.getmaxyx()
            if current_height != height or current_width != width:
                height, width = current_height, current_width
                # Aggiorna anche i componenti che dipendono dalle dimensioni
                renderer = ASCIIRenderer(width, height)
                ui = UserInterface(stdscr, width, height - 2)  # -2 per la barra comandi
                menu_system = get_menu_system(stdscr)  # Forza aggiornamento dimensioni
                logger.info(f"Terminale ridimensionato: {width}x{height}")
            
            # Rendering ottimizzato con cache
            stdscr.clear()
            
            # Rendering condizionale basato sulla vista attuale
            if game_state.current_view == "space":
                renderer.render_space(stdscr, player, universe, game_state)
            elif game_state.current_view == "starmap":
                renderer.render_starmap(stdscr, player, universe, game_state)
            elif game_state.current_view == "station":
                renderer.render_station(stdscr, player, universe, game_state)
                
            # Renderizza l'UI
            ui.render(stdscr, game_state)
            
            # Renderizza il menu dopo l'UI, con priorità massima
            menu_system.render()  # Questa chiamata è importante per visualizzare il menu
            
            # Aggiorna lo schermo esplicitamente
            stdscr.refresh()
            
            # Visualizza FPS se abilitato
            if show_fps:
                fps_str = f"FPS: {game_loop.get_current_fps():.1f}"
                try:
                    stdscr.addstr(0, width - len(fps_str) - 2, fps_str, curses.color_pair(3))
                except curses.error:
                    pass
            
            # Gestisce la fine del frame in modo ottimale
            game_loop.end_frame()
            
            # Profiling periodico
            frame_count += 1
            if frame_count % 100 == 0:
                profile_time = time.time() - last_profile_time
                logger.debug(f"Performance: 100 frames in {profile_time:.2f}s - Avg FPS: {100/profile_time:.1f}")
                last_profile_time = time.time()
    finally:
        # Pulizia finale
        memory_manager.forced_cleanup()
        logger.info("Game loop terminato")

if __name__ == "__main__":
    try:
        curses.wrapper(main)
    except KeyboardInterrupt:
        sys.exit(0)
